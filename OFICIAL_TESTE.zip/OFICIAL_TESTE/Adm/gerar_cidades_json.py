
"""
Baixa os municípios do IBGE e gera cidades.json.

Campos:
- cidade
- estado (UF)
- codigo_ibge

Compatível com Python 3.10+.
"""

import gzip
import json
import ssl
import urllib.error
import urllib.request
from pathlib import Path

import truststore


URL = "https://servicodados.ibge.gov.br/api/v1/localidades/municipios"

DESTINO = Path(__file__).resolve().parent / "cidades.json"


def consultar_ibge():
    """Consulta a API usando os certificados do Windows."""

    print("Conectando à API do IBGE...")

    contexto_ssl = truststore.SSLContext(
        ssl.PROTOCOL_TLS_CLIENT
    )

    requisicao = urllib.request.Request(
        URL,
        headers={
            "User-Agent": "Mozilla/5.0",
            "Accept": "application/json",
            "Accept-Encoding": "gzip"
        }
    )

    with urllib.request.urlopen(
        requisicao,
        timeout=60,
        context=contexto_ssl
    ) as resposta:

        dados = resposta.read()

        # Identifica compactação GZIP pelo cabeçalho.
        if dados.startswith(b"\x1f\x8b"):
            dados = gzip.decompress(dados)

        municipios = json.loads(
            dados.decode("utf-8-sig")
        )

    if not isinstance(municipios, list):
        raise ValueError(
            "A API retornou um formato inesperado."
        )

    print(f"Municípios recebidos: {len(municipios)}")

    return municipios


def obter_uf(municipio):
    """Extrai a sigla da UF do município."""

    microrregiao = municipio.get("microrregiao") or {}
    mesorregiao = microrregiao.get("mesorregiao") or {}

    uf = (mesorregiao.get("UF") or {}).get("sigla")

    if not uf:
        regiao_imediata = (
            municipio.get("regiao-imediata") or {}
        )

        regiao_intermediaria = (
            regiao_imediata.get("regiao-intermediaria") or {}
        )

        uf = (
            regiao_intermediaria.get("UF") or {}
        ).get("sigla")

    return uf.upper() if isinstance(uf, str) else None


def processar_municipios(municipios):
    """Organiza e ordena os municípios."""

    cidades = []
    ignorados = 0

    for municipio in municipios:

        if not isinstance(municipio, dict):
            ignorados += 1
            continue

        nome = municipio.get("nome")
        codigo = municipio.get("id")
        uf = obter_uf(municipio)

        if not isinstance(nome, str) or not uf:
            ignorados += 1
            continue

        cidades.append({
            "cidade": nome.strip(),
            "estado": uf,
            "codigo_ibge": codigo
        })

    cidades.sort(
        key=lambda item: (
            item["estado"],
            item["cidade"].casefold()
        )
    )

    if ignorados:
        print(f"Registros ignorados: {ignorados}")

    return cidades


def salvar_json(cidades):
    """Salva os dados em formato JSON UTF-8."""

    if not cidades:
        raise ValueError(
            "Nenhum município válido foi encontrado."
        )

    # Salva primeiro em arquivo temporário.
    # Evita deixar o JSON principal incompleto.
    temporario = DESTINO.with_suffix(".json.tmp")

    try:
        with temporario.open(
            "w",
            encoding="utf-8"
        ) as arquivo:

            json.dump(
                cidades,
                arquivo,
                ensure_ascii=False,
                indent=2
            )

        temporario.replace(DESTINO)

    finally:
        if temporario.exists():
            temporario.unlink()

    print("\nArquivo gerado com sucesso!")
    print(f"Total de cidades: {len(cidades)}")
    print(f"Local: {DESTINO}")


def gerar():
    """Executa o processo completo."""

    try:
        municipios = consultar_ibge()
        cidades = processar_municipios(municipios)
        salvar_json(cidades)

    except urllib.error.HTTPError as erro:
        print(
            f"Erro HTTP {erro.code}: {erro.reason}"
        )

    except urllib.error.URLError as erro:
        print(f"Erro de conexão: {erro.reason}")

    except ssl.SSLError as erro:
        print(f"Erro de certificado SSL: {erro}")

    except (OSError, ValueError, EOFError) as erro:
        print(f"Erro ao gerar JSON: {erro}")

    except Exception as erro:
        print(
            f"Erro inesperado: "
            f"{type(erro).__name__}: {erro}"
        )


if __name__ == "__main__":
    gerar()
