import json
import unicodedata
from pathlib import Path
import tkinter as tk
from tkinter import ttk, messagebox, simpledialog
from datetime import datetime

if __package__ and "." in __package__:
    from ..controllers.controller import Controller
    from ..services.etiqueta import abrir_etiqueta
    from . import dashboard_design as design
else:
    from controllers.controller import Controller
    from services.etiqueta import abrir_etiqueta
    from views import dashboard_design as design


class DashboardCTe(tk.Tk):
    """Janela principal do cadastro de CT-e."""

    def __init__(self):
        super().__init__()

        self.controller = Controller()
        self.modal_motorista = None
        self.modal_resultados = None

        self.title(design.WINDOW_TITLE)
        self.geometry(design.WINDOW_SIZE)
        self.minsize(design.WINDOW_MIN_WIDTH, design.WINDOW_MIN_HEIGHT)
        self.configure(bg=design.BG)

        design.configurar_estilos(self)
        self._carregar_cidades()
        self._atualizadores_clientes = []
        self._criar_variaveis()
        self._criar_interface()
        self._atualizar_relogio()

    def _criar_variaveis(self):
        """Cria as variáveis vinculadas aos campos e aos cards da tela."""
        self.placeholder_data = "dd/mm/aaaa"
        self.placeholder_ajuda="leia uma chave de 44 digitos"
        self.remetente_var = tk.StringVar()
        self.destinatario_var=tk.StringVar()
        self.codigo_var = tk.StringVar(value=self.placeholder_ajuda)
        self.numero_documento_var = tk.StringVar()
        self.cidade_origem_var = tk.StringVar()
        self.uf_origem_var = tk.StringVar()
        self.cidade_destino_var = tk.StringVar()
        self.uf_destino_var = tk.StringVar()
        self.placa_var = tk.StringVar()
        self.motorista_var = tk.StringVar()
        self.data_var = tk.StringVar(value=self.placeholder_data)
        self.observacao_var = tk.StringVar()

        self.ultimo_cte_var = tk.StringVar(value="-")
        self.cliente_var = tk.StringVar(value="-")
        self.card_motorista_var = tk.StringVar(value="-")
        self.card_placa_var = tk.StringVar(value="-")

    def _criar_interface(self):
        """Monta a estrutura principal da janela."""
        area = tk.Frame(self, bg=design.BG)
        area.pack(fill="both", expand=True)

        self._criar_topbar(area)

        # O rodapé é reservado antes do conteúdo expansível para que
        # os botões permaneçam visíveis na janela normal e maximizada.
        self._criar_rodape(area)

        # Somente o conteúdo rola; o rodapé permanece acessível.
        conteudo = tk.Frame(area, bg=design.BG)
        conteudo.pack(
            fill="both",
            expand=True,
            padx=design.CONTENT_PAD_X,
            pady=(design.CONTENT_PAD_TOP, design.CONTENT_PAD_BOTTOM),
        )
        self._criar_cabecalho(conteudo)
        self._criar_cards(conteudo)
        self._criar_formulario(conteudo)


    def _criar_topbar(self, parent):
        """Cria a barra superior com marca, data, hora e indicador."""
        topbar = tk.Frame(parent, bg=design.WHITE, height=design.TOPBAR_HEIGHT)
        topbar.pack(fill="x")
        topbar.pack_propagate(False)

        marca = tk.Label(
            topbar,
            text="TRANSANCHES TRANSPORTES",
            font=design.FONT_LABEL,
            fg=design.NAVY,
            bg=design.WHITE,
        )
        marca.pack(side="left", padx=1)

        direita = tk.Frame(topbar, bg=design.WHITE)
        direita.pack(side="right", padx=18, fill="y")

        self.relogio_label = tk.Label(
            direita,
            text="--/--/----  •  --:--:--",
            **design.LABEL_MUTED,
        )
        self.relogio_label.pack(side="left", pady=16)

        tk.Label(
            direita,
            text="●",
            font=design.FONT_SMALL,
            fg=design.SUCCESS,
            bg=design.WHITE,
        ).pack(side="left", padx=(10, 0), pady=16)

        tk.Frame(parent, bg=design.BORDER, height=1).pack(fill="x")

    def _criar_cabecalho(self, parent):
        """Cria o título e a descrição da tela."""
        cabecalho = tk.Frame(parent, bg=design.BG)
        cabecalho.pack(fill="x", pady=(12, 8))

        textos = tk.Frame(cabecalho, bg=design.BG)
        textos.pack(side="left", fill="x", expand=True)

        tk.Label(
            textos,
            text="Cadastro de CT-e",
            **design.TITLE_STYLE,
        ).pack(anchor="w")

        tk.Label(
            textos,
            text="Registre e consulte os dados do transporte",
            font=design.FONT_NORMAL,
            fg=design.MUTED,
            bg=design.BG,
        ).pack(anchor="w", pady=(2, 0))

    def _criar_cards(self, parent):
        """Cria os cards com os dados do último documento trabalhado."""
        cards = tk.Frame(parent, bg=design.BG)
        cards.pack(fill="x", pady=(0, 10))

        dados = (
            ("Último documento", self.ultimo_cte_var),
            ("Cliente", self.cliente_var),
            ("Motorista", self.card_motorista_var),
            ("Placa", self.card_placa_var),
        )

        for coluna, (titulo, variavel) in enumerate(dados):
            cards.grid_columnconfigure(coluna, weight=1, uniform="cards")
            self._criar_card(cards, titulo, variavel, coluna)

    def _criar_card(self, parent, titulo, variavel, coluna):
        card = tk.Frame(parent, **design.CARD_STYLE)
        card.grid(row=0, column=coluna, sticky="nsew", padx=4)

        tk.Label(
            card,
            text=titulo,
            font=design.FONT_LABEL,
            fg=design.MUTED,
            bg=design.WHITE,
        ).pack(anchor="w", padx=12, pady=(8, 1))

        tk.Label(
            card,
            textvariable=variavel,
            font=design.FONT_CARD_VALUE,
            fg=design.NAVY,
            bg=design.WHITE,
            anchor="w",
        ).pack(fill="x", padx=12, pady=(0, 7))

    def _criar_formulario(self, parent):
        """Cria os campos do formulário principal e registra seus eventos."""
        container = tk.Frame(
            parent,
            **design.FORM_CONTAINER_STYLE
        )
        container.pack(fill="both", expand=True)

        # Cabeçalho
        cabecalho = tk.Frame(
            container,
            bg=design.WHITE
        )
        cabecalho.pack(
            fill="x",
            padx=16,
            pady=8
        )

        tk.Label(
            cabecalho,
            text="Dados de Transporte",
            **design.SECTION_TITLE_STYLE,
        ).pack(side="left")

        tk.Label(
            cabecalho,
            text="Preencha os dados abaixo para cadastrar o CT-e",
            **design.LABEL_MUTED,
        ).pack(
            side="left",
            padx=16,
            pady=3
        )

        tk.Frame(
            container,
            bg=design.BORDER,
            height=1
        ).pack(
            fill="x",
            padx=16
        )

        # Corpo do formulário
        corpo = tk.Frame(
            container,
            bg=design.WHITE
        )
        corpo.pack(
            fill="both",
            expand=True,
            padx=design.FORM_PAD_X,
            pady=design.FORM_PAD_Y,
        )

        for coluna in range(6):
            corpo.grid_columnconfigure(
                coluna,
                weight=1,
                uniform="campos"
            )

        # Linha 1
        self.remetente_entry = self.criar_combobox_cliente(
            corpo, "Remetente", self.remetente_var, 0, 0, 2, "origem"
        )
        self.destinatario_entry = self.criar_combobox_cliente(
            corpo, "Destinatário", self.destinatario_var, 0, 2, 2, "destino"
        )
        self.codigo_entry = self._criar_campo(
            corpo, "Chave NF-e / CT-e", self.codigo_var, 0, 4, 2
        )
        self.codigo_entry.bind(
            "<Button-1>",
            lambda event: self.codigo_var.set("")
            if self.codigo_var.get() == self.placeholder_ajuda
            else None,
        )

        # Linha 2
        self.numero_documento_entry = self._criar_campo(
            corpo,
            "Número NF-e / CT-e",
            self.numero_documento_var,
            1,
            0,
            2
        )
        # Começa livre para permitir digitação manual do número do CT-e.
        # Será bloqueado apenas quando vier de um código de barras válido.
        self.numero_documento_entry.config(
            state="normal",
            style="TEntry",
        )


        self.placa_entry = self._criar_campo(
            corpo,
            "Placa",
            self.placa_var,
            1,
            2,
            2
        )

        self.motorista_entry = self._criar_campo(
            corpo,
            "Motorista",
            self.motorista_var,
            1,
            4,
            2
        )

        # O motorista é preenchido pela consulta da placa ou pelo modal.
        self.motorista_entry.config(
            state="readonly",
            style="Data.TEntry",
        )

        # Linha 3: data e rota, com cidades expansíveis e UFs estreitas.
        linha_rota = tk.Frame(corpo, bg=design.WHITE)
        linha_rota.grid(row=2, column=0, columnspan=6, sticky="ew")
        for coluna in (2, 4):
            linha_rota.grid_columnconfigure(coluna, weight=1, uniform="cidades")
        self.data_entry = self._criar_campo(
            linha_rota, "Data", self.data_var, 0, 0,
        )
        self.data_entry.configure(width=11)

        self.data_entry.config(
            state="normal",
            foreground=design.MUTED
        )
        self.data_entry.bind(
            "<FocusIn>",
            lambda event: (
                self.data_var.set(""),
                self.data_entry.configure(foreground=design.TEXT),
            )
            if self.data_var.get() == self.placeholder_data
            else None,
        )

        self.data_entry.bind(
            "<FocusOut>",
            lambda event: (
                self.data_var.set(self.placeholder_data),
                self.data_entry.configure(foreground=design.MUTED),
            )
            if not self.data_var.get().strip()
            else None,
        )
        # Primeiro UF e depois Cidade, para origem e destino.
        for local, coluna in (("origem", 1), ("destino", 3)):
            bloco = tk.Frame(linha_rota, bg=design.WHITE)
            bloco.grid(row=0, column=coluna, sticky="ew",
                       padx=design.FIELD_PAD_X, pady=(0, design.FIELD_PAD_BOTTOM))
            tk.Label(bloco, text=f"UF de {local}", **design.LABEL_NORMAL).pack(anchor="w")
            uf = ttk.Combobox(bloco, textvariable=getattr(self, f"uf_{local}_var"),
                              values=Controller.UFS, state="readonly", width=5)
            uf.pack(fill="x", pady=(4, 0))
            setattr(self, f"uf_{local}_entry", uf)
            cidade = self._criar_campo_cidade(
                linha_rota, f"Cidade de {local}",
                getattr(self, f"cidade_{local}_var"),
                getattr(self, f"uf_{local}_var"), 0, coluna + 1)
            setattr(self, f"cidade_{local}_entry", cidade)

        # Último campo, depois de origem e destino.
        self.observacao_entry = self._criar_campo(
            corpo, "Observação", self.observacao_var, 3, 0, 6,
        )

        tk.Label(
            corpo,
            text="Para melhor visualização, maximize a janela.",
            font=design.FONT_SMALL,
            fg=design.MUTED,
            bg=design.WHITE,
        ).grid(
            row=4,
            column=0,
            columnspan=6,
            sticky="w",
            padx=design.FIELD_PAD_X,
            pady=(0, 8),
        )

        def chave_alterada(*args):
            # Uma nova chave não pode manter o número extraído da anterior.
            self.numero_documento_var.set("")
            self.numero_documento_entry.configure(state="normal", style="TEntry")

        self.codigo_var.trace_add("write", chave_alterada)

        # Eventos
        self.codigo_entry.bind(
            "<Return>",
            self._ao_confirmar_codigo
        )

        self.placa_entry.bind(
            "<Return>",
            self._consultar_motorista_placa
        )
        # Ao abrir, posiciona o cursor no código
        self.codigo_entry.focus_set()
    def _criar_campo(
        self,
        parent,
        titulo,
        variavel,
        linha,
        coluna,
        quantidade_colunas=1,
        ajuda=None,
    ):
        bloco = tk.Frame(parent, bg=design.WHITE)
        bloco.grid(
            row=linha,
            column=coluna,
            columnspan=quantidade_colunas,
            sticky="ew",
            padx=design.FIELD_PAD_X,
            pady=(0, design.FIELD_PAD_BOTTOM),
        )

        tk.Label(
            bloco,
            text=titulo,
            font=design.FONT_LABEL,
            fg=design.TEXT,
            bg=design.WHITE,
        ).pack(anchor="w", pady=(0, 4))

        entrada = ttk.Entry(bloco, textvariable=variavel)
        entrada.pack(fill="x")

        if ajuda:
            tk.Label(
                bloco,
                text=ajuda,
                font=design.FONT_HELP,
                fg=design.MUTED,
                bg=design.WHITE,
            ).pack(anchor="w", pady=(3, 0))

        return entrada

    @staticmethod
    def _chave_cidade(texto):
        texto = unicodedata.normalize("NFKD", str(texto or ""))
        return "".join(c for c in texto if not unicodedata.combining(c)).casefold()

    def _carregar_cidades(self):
        """Lê cidades.json local; sem ele utiliza cidades dos clientes existentes."""
        caminho = Path(__file__).resolve().parents[1] / "cidades.json"
        self.cidades_por_uf = {uf: [] for uf in Controller.UFS}
        if caminho.exists():
            try:
                registros = json.loads(caminho.read_text(encoding="utf-8-sig"))
            except (OSError, ValueError) as erro:
                raise RuntimeError(f"Erro no cidades.json: {erro}") from erro
        else:
            registros = [
                {"cidade": c.get("cidade"), "estado": c.get("uf")}
                for c in self.controller.consultar_clientes()
            ]
        for item in registros:
            if not isinstance(item, dict):
                continue
            cidade = str(item.get("cidade") or "").strip()
            uf = str(item.get("estado") or item.get("uf") or "").strip().upper()
            if cidade and uf in self.cidades_por_uf:
                self.cidades_por_uf[uf].append(cidade)
        for uf, nomes in self.cidades_por_uf.items():
            self.cidades_por_uf[uf] = sorted(set(nomes), key=self._chave_cidade)
        self.lista_cidades_completa = caminho.exists()

    def _criar_campo_cidade(self, parent, titulo, cidade_var, uf_var, linha, coluna):
        bloco = tk.Frame(parent, bg=design.WHITE)
        bloco.grid(row=linha, column=coluna, sticky="ew",
                   padx=design.FIELD_PAD_X, pady=(0, design.FIELD_PAD_BOTTOM))
        tk.Label(bloco, text=titulo, **design.LABEL_NORMAL).pack(anchor="w")
        combo = ttk.Combobox(bloco, textvariable=cidade_var, state="normal", width=18)
        combo.pack(fill="x", pady=(4, 0))
        def atualizar(*_):
            termo = self._chave_cidade(cidade_var.get().strip())
            opcoes = self.cidades_por_uf.get(uf_var.get(), [])
            if len(termo) >= 3:
                opcoes = [nome for nome in opcoes if self._chave_cidade(nome).startswith(termo)]
            combo.configure(values=opcoes)
        def mudar_uf(*_):
            cidade_var.set("")
            atualizar()
        uf_var.trace_add("write", mudar_uf)
        cidade_var.trace_add("write", atualizar)
        combo.bind("<FocusIn>", atualizar)
        return combo

    def _abrir_modal_cliente(self):
        """Cadastro simples: nome, UF e cidade selecionada no JSON."""
        modal = tk.Toplevel(self)
        modal.title("Cadastrar cliente")
        modal.configure(bg=design.WHITE)
        modal.transient(self)
        modal.resizable(False, False)
        self._centralizar_modal(modal, 480, 350)
        modal.grab_set()
        corpo = tk.Frame(modal, bg=design.WHITE)
        corpo.pack(fill="both", expand=True, padx=24, pady=20)
        tk.Label(corpo, text="Novo cliente", **design.SECTION_TITLE_STYLE).pack(anchor="w", pady=(0, 12))
        nome_var = tk.StringVar()
        uf_var = tk.StringVar()
        cidade_var = tk.StringVar()
        self._criar_campo_modal(corpo, "Nome do cliente", nome_var)
        tk.Label(corpo, text="Estado (UF)", **design.LABEL_NORMAL).pack(anchor="w")
        uf_combo = ttk.Combobox(corpo, textvariable=uf_var, values=Controller.UFS, state="readonly")
        uf_combo.pack(fill="x", pady=(4, 12))
        tk.Label(corpo, text="Cidade (digite 3 letras)", **design.LABEL_NORMAL).pack(anchor="w")
        cidade_combo = ttk.Combobox(corpo, textvariable=cidade_var, state="normal")
        cidade_combo.pack(fill="x", pady=(4, 14))
        def filtrar(*_):
            termo = self._chave_cidade(cidade_var.get())
            opcoes = self.cidades_por_uf.get(uf_var.get(), [])
            if len(termo) >= 3:
                opcoes = [n for n in opcoes if self._chave_cidade(n).startswith(termo)]
            cidade_combo.configure(values=opcoes)
        def alterar_uf(*_):
            cidade_var.set("")
            filtrar()
        uf_var.trace_add("write", alterar_uf)
        cidade_var.trace_add("write", filtrar)
        def salvar():
            nome, uf, cidade = nome_var.get().strip(), uf_var.get(), cidade_var.get().strip()
            if not nome or not uf or not cidade:
                messagebox.showwarning("Dados incompletos", "Informe nome, UF e cidade.", parent=modal)
                return
            opcoes = self.cidades_por_uf.get(uf, [])
            if opcoes:
                cidade_correta = next((n for n in opcoes if self._chave_cidade(n) == self._chave_cidade(cidade)), None)
                if not cidade_correta:
                    messagebox.showwarning("Cidade inválida", "Selecione uma cidade da lista.", parent=modal)
                    return
                cidade = cidade_correta
            try:
                cliente = self.controller.cadastrar_cliente(nome, cidade, uf)
            except Exception as erro:
                messagebox.showerror("Erro", str(erro), parent=modal)
                return
            # Atualiza o cliente no formulário e na lista de autocomplete.
            self._mostrar_status(f"Cliente {cliente['nome']} cadastrado.", design.SUCCESS)
            modal.destroy()
            for atualizar in self._atualizadores_clientes:
                atualizar()
            messagebox.showinfo("Cliente salvo", "Cliente cadastrado e disponível nas listas de remetente e destinatário.", parent=self)
        botoes = tk.Frame(corpo, bg=design.WHITE)
        botoes.pack(fill="x")
        tk.Button(botoes, text="Cancelar", command=modal.destroy,
                  **design.BUTTON_OUTLINE).pack(side="left", expand=True, fill="x", padx=(0, 5))
        tk.Button(botoes, text="Salvar", command=salvar,
                  **design.BUTTON_PRIMARY).pack(side="left", expand=True, fill="x", padx=(5, 0))

    def _criar_rodape(self, parent):
        """Cria a barra de status e os botões principais."""
        rodape = tk.Frame(
            parent,
            bg=design.WHITE,
            height=design.FOOTER_HEIGHT,
            highlightbackground=design.BORDER,
            highlightthickness=1,
        )
        rodape.pack(side="bottom", fill="x")
        # Altura natural: evita cortar botões com escala de fontes maior.

        informacoes = tk.Frame(rodape, bg=design.WHITE)
        informacoes.pack(fill="x", padx=14, pady=(7, 3))

        self.status_label = tk.Label(
            informacoes,
            text="● Pronto para receber um CT-e",
            font=design.FONT_SMALL,
            fg=design.SUCCESS,
            bg=design.WHITE,
            anchor="w",
        )
        self.status_label.pack(side="left", fill="x", expand=True)


        botoes = tk.Frame(rodape, bg=design.WHITE)
        botoes.pack(fill="x", padx=14, pady=(0, 7))

        for coluna in range(4):
            botoes.grid_columnconfigure(coluna, weight=1, uniform="acoes")

        tk.Button(
            botoes, text="Cad. Cliente", command=self._abrir_modal_cliente,
            **design.BUTTON_OUTLINE,
        ).grid(row=0, column=0, sticky="ew", padx=4)

        tk.Button(
            botoes,
            text="Cad. Motorista",
            command=self._abrir_modal_motorista,
            **design.BUTTON_OUTLINE,
        ).grid(row=0, column=1, sticky="ew", padx=4)

        tk.Button(
            botoes,
            text="Consultar",
            command=self._consultar,
            **design.BUTTON_SECONDARY,
        ).grid(row=0, column=2, sticky="ew", padx=4)

        tk.Button(
            botoes,
            text="Cadastrar",
            command=lambda: self._executar_acao(
                self.controller.cadastrar,
                "Não foi possível cadastrar o CT-e.",
                limpar_apos_sucesso=True,
            ),
            **design.BUTTON_PRIMARY,
        ).grid(row=0, column=3, sticky="ew", padx=4)

    # --------------------------------------------------------
    # COMUNICAÇÃO ENTRE A VIEW E O CONTROLLER
    # --------------------------------------------------------
    def _obter_dados_formulario(self):
        """Lê os campos e devolve os dados esperados pelo Controller."""
        return {
            "remetente": self.remetente_var.get().strip(),
            "codigo_barras": self.codigo_var.get().strip(),
            "numero_documento": self.numero_documento_var.get().strip(),
            "destinatario": self.destinatario_var.get().strip(),
            "cidade_origem": self.cidade_origem_var.get().strip(),
            "uf_origem": self.uf_origem_var.get().strip(),
            "cidade_destino": self.cidade_destino_var.get().strip(),
            "uf_destino": self.uf_destino_var.get().strip(),
            "placa": self.placa_var.get().strip(),
            "motorista": self.motorista_var.get().strip(),
            "data": self.data_var.get().strip(),
            "observacao": self.observacao_var.get().strip(),
        }

    def _personalizar_nomes_etiqueta(self, dados):
        """Pede nome de impressão só para clientes sem preferência cadastrada.

        Retorna cópia dos dados pronta para imprimir, ou None ao cancelar.
        Nunca modifica os nomes originais do documento.
        """
        dados_impressao = dict(dados)
        pendentes = []
        for papel, campo_cidade, campo_uf, campo_id in (
            ("remetente", "cidade_origem", "uf_origem", "id_remetente"),
            ("destinatario", "cidade_destino", "uf_destino", "id_destinatario"),
        ):
            nome_original = str(dados.get(papel) or "").strip()
            if not nome_original:
                continue
            cliente = self.controller.localizar_cliente_etiqueta(
                nome_original, dados.get(campo_cidade), dados.get(campo_uf),
                dados.get(campo_id),
            )
            if cliente is None:
                # Não vincula automaticamente a um cadastro ambíguo.
                dados_impressao[papel] = nome_original
                continue
            nome_salvo = str(cliente.get("nome_etiqueta") or "").strip()
            if nome_salvo:
                dados_impressao[papel] = nome_salvo
            else:
                pendentes.append((papel, cliente, nome_original))

        if not pendentes:
            return dados_impressao

        modal = tk.Toplevel(self)
        modal.title("Personalizar nomes para impressão")
        modal.configure(bg=design.WHITE)
        modal.transient(self)
        modal.resizable(False, False)
        self._centralizar_modal(modal, 540, 180 + 110 * len(pendentes))
        modal.grab_set()
        container = tk.Frame(modal, bg=design.WHITE)
        container.pack(fill="both", expand=True, padx=22, pady=18)
        tk.Label(container, text="Como os clientes devem aparecer na etiqueta?",
                 **design.SECTION_TITLE_STYLE).pack(anchor="w", pady=(0, 12))
        entradas = []
        for papel, cliente, nome_original in pendentes:
            tk.Label(container, text=f"{papel.capitalize()}: {nome_original}",
                     font=design.FONT_LABEL, fg=design.TEXT, bg=design.WHITE,
                     wraplength=480, justify="left").pack(anchor="w", pady=(7, 3))
            variavel = tk.StringVar(master=modal, value=nome_original)
            ttk.Entry(container, textvariable=variavel).pack(fill="x")
            entradas.append((papel, cliente, variavel))
        tk.Label(container, text="O nome será lembrado nas próximas impressões.",
                 font=design.FONT_SMALL, fg=design.MUTED, bg=design.WHITE).pack(
                     anchor="w", pady=(12, 5))
        estado = {"confirmado": False}

        def cancelar():
            modal.destroy()

        def confirmar():
            valores = [(papel, cliente, var.get().strip())
                       for papel, cliente, var in entradas]
            if any(not valor for _, _, valor in valores):
                messagebox.showwarning("Nome obrigatório",
                    "Preencha todos os nomes de impressão.", parent=modal)
                return
            try:
                for papel, cliente, valor in valores:
                    if not self.controller.atualizar_nome_etiqueta(cliente["id"], valor):
                        raise ValueError(f"Cliente não encontrado: {cliente['nome']}")
                    dados_impressao[papel] = valor
            except Exception as erro:
                messagebox.showerror("Erro ao salvar preferência", str(erro), parent=modal)
                return
            estado["confirmado"] = True
            modal.destroy()

        botoes = tk.Frame(container, bg=design.WHITE)
        botoes.pack(fill="x", pady=(10, 0))
        tk.Button(botoes, text="Cancelar", command=cancelar,
                  **design.BUTTON_OUTLINE).pack(side="left", fill="x", expand=True, padx=(0, 5))
        tk.Button(botoes, text="Salvar e imprimir", command=confirmar,
                  **design.BUTTON_PRIMARY).pack(side="left", fill="x", expand=True, padx=(5, 0))
        modal.protocol("WM_DELETE_WINDOW", cancelar)
        modal.wait_window()
        return dados_impressao if estado["confirmado"] else None

    def _executar_acao(
        self,
        acao,
        mensagem_padrao,
        limpar_apos_sucesso=False,
    ):
        """Captura os campos, chama o Controller e trata seu retorno."""

        try:
            dados = self._obter_dados_formulario()
            resultado = acao(dados)
        except Exception as erro:
            self._mostrar_status(f"Erro: {erro}", design.DANGER)
            return

        if not isinstance(resultado, dict):
            self._mostrar_status(
                "O Controller devolveu uma resposta inválida.",
                design.DANGER,
            )
            return

        self._mostrar_resultado(resultado, mensagem_padrao)

        if resultado.get("sucesso", False) and limpar_apos_sucesso:
            self._atualizar_cards_apos_cadastro(dados, resultado)
            dados_salvos = dict(resultado.get("dados") or dados)
            imprimir = messagebox.askyesno(
                "Cadastro confirmado",
                "Cadastro realizado com sucesso.\n\nDeseja imprimir a etiqueta?",
                parent=self,
            )
            quantidade = None
            if imprimir:
                quantidade = simpledialog.askinteger(
                    "Quantidade de paletes",
                    "Quantos paletes deseja imprimir?",
                    parent=self,
                    minvalue=1,
                )
            if quantidade is not None:
                try:
                    dados_impressao = self._personalizar_nomes_etiqueta(dados_salvos)
                    if dados_impressao is not None:
                        abrir_etiqueta(dados_impressao, quantidade=quantidade)
                    if dados_impressao is not None:
                        self._mostrar_status(
                            "Cadastro salvo. Etiqueta aberta no navegador para impressão.",
                            design.SUCCESS,
                        )
                except Exception as erro:
                    messagebox.showwarning(
                        "Cadastro salvo — impressão não aberta",
                        f"O documento já está salvo. Não cadastre novamente.\n\n{erro}",
                        parent=self,
                    )
            self._limpar_formulario_principal()

    # --------------------------------------------------------
    # MODAL DE MOTORISTA E PLACA
    # --------------------------------------------------------
    def _abrir_modal_motorista(self):
        """Permite selecionar um motorista existente ou digitar um novo."""
        if self.modal_motorista and self.modal_motorista.winfo_exists():
            self.modal_motorista.lift()
            self.modal_motorista.focus_force()
            return

        # Consulta pelo Controller antes de abrir o modal.
        try:
            motoristas = self.controller.listar_motoristas()
            nomes_motoristas = [
                motorista["nome"]
                for motorista in motoristas
            ]
        except Exception as erro:
            self._mostrar_status(
                f"Erro ao carregar motoristas: {erro}",
                design.DANGER,
            )
            return

        modal = tk.Toplevel(self)
        self.modal_motorista = modal

        modal.title("Cadastro de motorista e placa")
        modal.geometry("480x500")
        self._centralizar_modal(modal, 480, 500)
        modal.resizable(False, False)
        modal.configure(bg=design.WHITE)
        modal.transient(self)
        modal.grab_set()
        modal.protocol(
            "WM_DELETE_WINDOW",
            self._fechar_modal_motorista,
        )

        self._centralizar_modal(modal, 480, 420)

        placa_modal_var = tk.StringVar(
            master=modal,
            value=self.placa_var.get(),
        )
        motorista_modal_var = tk.StringVar(
            master=modal,
            value=self.motorista_var.get(),
        )
        rg_modal_var=tk.StringVar(
            master=modal,

        )
        container = tk.Frame(modal, bg=design.WHITE)
        container.pack(
            fill="both",
            expand=True,
            padx=28,
            pady=24,
        )

        tk.Label(
            container,
            text="Cadastrar motorista e placa",
            **design.SECTION_TITLE_STYLE,
        ).pack(anchor="w")

        tk.Label(
            container,
            text="Placa existente: atualiza o motorista vinculado.",
            **design.LABEL_MUTED,
        ).pack(anchor="w", pady=(3, 18))

        placa_entry = self._criar_campo_modal(
            container,
            "Placa",
            placa_modal_var,
        )

        # Combobox editável: seleção ou digitação de um nome novo.
        bloco_motorista = tk.Frame(
            container,
            bg=design.WHITE,
        )
        bloco_motorista.pack(fill="x", pady=(0, 14))

        tk.Label(
            bloco_motorista,
            text="Motorista",
            font=design.FONT_LABEL,
            fg=design.TEXT,
            bg=design.WHITE,
        ).pack(anchor="w", pady=(0, 5))

        motorista_entry = ttk.Combobox(
            bloco_motorista,
            textvariable=motorista_modal_var,
            values=nomes_motoristas,
            state="normal",
            height=8,
        )
        motorista_entry.focus_set()

        # Posiciona o cursor no final do texto existente.
        motorista_entry.icursor(tk.END)
        motorista_entry.pack(fill="x")
        rg_entry = self._criar_campo_modal(
            container,
            "RG",
            rg_modal_var,


        )

        tk.Label(
            bloco_motorista,
            text="Digite para filtrar e abra a seta para selecionar.\n"
                 "Para cadastrar, digite um nome novo e clique em Salvar.",
            **design.LABEL_MUTED,
        ).pack(anchor="w", pady=(5, 0))

        mensagem_label = tk.Label(
            container,
            text="",
            font=design.FONT_SMALL,
            fg=design.DANGER,
            bg=design.WHITE,
            anchor="w",
            justify="left",
            wraplength=420,
        )
        mensagem_label.pack(fill="x", pady=(2, 12))

        def preencher_rg(*args):
            nome_selecionado = (
                motorista_modal_var.get().strip().casefold()
            )

            for motorista in motoristas:
                if motorista["nome"].strip().casefold() == nome_selecionado:
                    # Preenche o RG do motorista existente.
                    rg_modal_var.set(motorista["rg"] or "")

                    # Bloqueia o campo RG.
                    rg_entry.configure(state="readonly")

                    return

            # Motorista novo: limpa e libera o RG.
            rg_modal_var.set("")
            rg_entry.configure(state="normal")

        def filtrar_motoristas(*args):
            termo = motorista_modal_var.get().strip().casefold()

            # Menos de 3 letras: apresenta a lista completa.
            if len(termo) < 3:
                motorista_entry.configure(
                    values=nomes_motoristas
                )
                mensagem_label.configure(text="")
                return

            encontrados = [
                nome
                for nome in nomes_motoristas
                if nome.casefold().startswith(termo)
            ]

            motorista_entry.configure(values=encontrados)

            mensagem_label.configure(text="")

            if encontrados:
                motorista_entry.event_generate("<Down>")

        # Atualiza a lista durante a digitação.
        motorista_modal_var.trace_add(
            "write",
            filtrar_motoristas
        )

        # Preenche ou libera o RG durante a digitação.
        motorista_modal_var.trace_add(
            "write",
            preencher_rg
        )

        # Preenche o RG também ao selecionar pela lista.
        motorista_entry.bind(
            "<<ComboboxSelected>>",
            preencher_rg
        )

        # Coloca o cursor no campo Motorista após abrir o modal.
        modal.after(100, motorista_entry.focus_set)


        def salvar(event=None):
            # Usa a grafia do cadastro existente quando o nome coincide.
            nome_digitado = motorista_modal_var.get().strip()

            for nome in nomes_motoristas:
                if nome.casefold() == nome_digitado.casefold():
                    motorista_modal_var.set(nome)
                    break
            self._salvar_motorista_modal(
                placa_modal_var,
                motorista_modal_var,
                mensagem_label,
                rg_modal_var,
            )
            return "break"

        botoes_modal = tk.Frame(container, bg=design.WHITE)
        botoes_modal.pack(side="bottom", fill="x")

        tk.Button(
            botoes_modal,
            text="Cancelar",
            command=self._fechar_modal_motorista,
            **design.BUTTON_OUTLINE,
        ).pack(
            side="left",
            fill="x",
            expand=True,
            padx=(0, 5),
        )

        tk.Button(
            botoes_modal,
            text="Salvar",
            command=salvar,
            **design.BUTTON_PRIMARY,
        ).pack(
            side="left",
            fill="x",
            expand=True,
            padx=(5, 0),
        )

        placa_entry.bind(
            "<FocusOut>",
            lambda event: placa_modal_var.set(
                self._normalizar_placa(placa_modal_var.get())
            ),
        )

        def focar_motorista(event=None):
            motorista_entry.focus_set()
            return "break"

        placa_entry.bind("<Return>", focar_motorista)

        # No Combobox, Enter fica disponível para selecionar um nome.
        # A gravação é feita pelo botão Salvar.
        placa_entry.focus_set()

    def _criar_campo_modal(self, parent, titulo, variavel):
        bloco = tk.Frame(parent, bg=design.WHITE)
        bloco.pack(fill="x", pady=(0, 14))

        tk.Label(
            bloco,
            text=titulo,
            font=design.FONT_LABEL,
            fg=design.TEXT,
            bg=design.WHITE,
        ).pack(anchor="w", pady=(0, 5))

        entrada = ttk.Entry(bloco, textvariable=variavel)
        entrada.pack(fill="x")
        return entrada

    def _fechar_modal_motorista(self):
        if self.modal_motorista and self.modal_motorista.winfo_exists():
            self.modal_motorista.grab_release()
            self.modal_motorista.destroy()

        self.modal_motorista = None

    def _centralizar_modal(self, modal, largura, altura):
        self.update_idletasks()
        posicao_x = self.winfo_rootx() + (self.winfo_width() - largura) // 2
        posicao_y = self.winfo_rooty() + (self.winfo_height() - altura) // 2
        modal.geometry(f"{largura}x{altura}+{posicao_x}+{posicao_y}")

    @staticmethod
    def _normalizar_placa(valor):
        placa = str(valor).strip().upper()
        placa = placa.replace("-", "").replace(" ", "")
        return f"{placa[:3]}-{placa[3:]}" if len(placa) == 7 else placa

    def _ao_confirmar_codigo(self, event=None):
        """Executa pelo Enter do leitor de código de barras."""
        self._extrair_numero_cte_nfe()
        return "break"
    def _consultar(self):
        """Consulta documentos e permite iniciar uma nova consulta."""
        try:
            filtros = self._obter_dados_formulario()
            resultado = self.controller.consultar(filtros)

        except Exception as erro:
            self._mostrar_status(
                f"Erro ao consultar: {erro}",
                design.DANGER,
            )
            return

        # Valida a resposta do Controller.
        if not isinstance(resultado, dict):
            self._mostrar_status(
                "O Controller devolveu uma resposta inválida.",
                design.DANGER,
            )
            return

        mensagem = resultado.get("mensagem") or "Consulta realizada."

        if not resultado.get("sucesso", False):
            self._mostrar_status(mensagem, design.DANGER)
            return

        registros = resultado.get("dados")

        if isinstance(registros, dict):
            registros = [registros]

        if registros is None:
            registros = []

        if not isinstance(registros, list) or any(
            not isinstance(registro, dict)
            for registro in registros
        ):
            self._mostrar_status(
                "Os dados retornados pelo Controller são inválidos.",
                design.DANGER,
            )
            return

        if not registros:
            self._mostrar_status(
                "Nenhum documento encontrado.",
                design.DANGER,
            )
            return

        # Vários documentos: a seleção acontece no modal.
        if len(registros) > 1:
            self._mostrar_status(mensagem, design.SUCCESS)
            self._abrir_modal_resultados(registros)
            return

        # Um documento: preenche o formulário.
        self._preencher_formulario(registros[0])
        self._mostrar_status(mensagem, design.SUCCESS)

    def _formatar_placa(self, event=None):
        self.placa_var.set(self._normalizar_placa(self.placa_var.get()))

    def _mostrar_resultado(self, resultado, mensagem_padrao):
        if isinstance(resultado, dict):
            sucesso = resultado.get("sucesso", False)
            mensagem = resultado.get("mensagem", mensagem_padrao)
            cor = design.SUCCESS if sucesso else design.DANGER
        else:
            mensagem = str(resultado) if resultado else mensagem_padrao
            cor = design.DANGER

        self._mostrar_status(mensagem, cor)

    def _mostrar_status(self, texto, cor=design.MUTED):
        self.status_label.config(text=f"● {texto}" if texto else "", fg=cor)

    def _atualizar_relogio(self):
        agora = datetime.now()
        self.relogio_label.config(text=agora.strftime("%d/%m/%Y  •  %H:%M:%S"))
        #self.hora_label.config(text=agora.strftime("Hora atual: %H:%M:%S"))
        self.after(1000, self._atualizar_relogio)
    def _extrair_numero_cte_nfe(self):
        """Uma chave identifica um documento: NF-e ou CT-e."""
        self.numero_documento_var.set("")
        self.numero_documento_entry.configure(state="normal", style="TEntry")
        codigo = self.codigo_var.get().strip()
        if not codigo:
            self._mostrar_status("", design.MUTED)
            return False
        try:
            resultado = self.controller.extrair_numero_cte_nf(codigo)
        except Exception as erro:
            self._mostrar_status(f"Erro: {erro}", design.DANGER)
            return False
        if not isinstance(resultado, dict):
            self._mostrar_status("Resposta inválida do Controller.", design.DANGER)
            return False
        if not resultado.get("sucesso"):
            self._mostrar_resultado(resultado, "Chave inválida.")
            return False
        self.numero_documento_var.set(resultado.get("numero_cte") or resultado.get("numero_nf") or "")
        self.numero_documento_entry.configure(state="readonly", style="Data.TEntry")
        self.data_var.set(datetime.now().strftime("%d/%m/%Y"))
        self.data_entry.configure(state="readonly", style="Data.TEntry")
        self._mostrar_status("", design.MUTED)
        return True

    def _consultar_motorista_placa(self, event=None):
        """Consulta o motorista vinculado à placa informada."""
        placa = self._normalizar_placa(self.placa_var.get())
        self.placa_var.set(placa)



        if not placa:
            self.motorista_var.set("")
            self._mostrar_status("Informe uma placa.", design.DANGER)
            return "break"

        try:
            resultado = self.controller.consultar_motorista_por_placa(placa)
        except Exception as erro:
            self.motorista_var.set("")
            self._mostrar_status(f"Erro ao consultar placa: {erro}", design.DANGER)
            return "break"

        if not isinstance(resultado, dict):
            self.motorista_var.set("")
            self._mostrar_status(
                "O Controller devolveu uma resposta inválida.",
                design.DANGER,
            )
            return "break"

        dados = resultado.get("dados") or {}
        if resultado.get("sucesso", False):
            motorista = dados.get("motorista", "")
            placa_encontrada = dados.get("placa", placa)
            self.motorista_var.set(motorista)

            self.card_motorista_var.set(motorista)
            self.card_placa_var.set(placa_encontrada)
        else:
            self.motorista_var.set("")
            self.card_motorista_var.set("")
            self.card_placa_var.set(placa)

        self._mostrar_resultado(
            resultado,
            "Não foi possível consultar a placa.",
        )

        return "break"

    def _salvar_motorista_modal(
            self,
            placa_variavel,
            motorista_variavel,
            mensagem_label,
            rg_variavel
    ):
        """Cadastra uma placa nova ou atualiza seu motorista."""

        placa = self._normalizar_placa(placa_variavel.get())
        motorista = motorista_variavel.get().strip()

        if not placa:
            mensagem_label.config(
                text="● Informe a placa.",
                fg=design.DANGER,
            )
            return

        if not motorista:
            mensagem_label.config(
                text="● Informe o nome do motorista.",
                fg=design.DANGER,
            )
            return
        dados = {
            "placa": placa,
            "motorista": motorista,
            "rg": rg_variavel.get().strip(),
        }


        try:
            resultado = self.controller.atualizar_motorista(dados)
        except Exception as erro:
            resultado = {
                "sucesso": False,
                "mensagem": f"Erro ao salvar motorista: {erro}",
            }

        if not isinstance(resultado, dict):
            resultado = {
                "sucesso": False,
                "mensagem": "O Controller devolveu uma resposta inválida.",
            }

        sucesso = resultado.get("sucesso", False)
        mensagem = resultado.get(
            "mensagem",
            "Não foi possível salvar o motorista.",
        )

        cor = design.SUCCESS if sucesso else design.DANGER
        mensagem_label.config(text=f"● {mensagem}", fg=cor)

        if not sucesso:
            return

        dados_salvos = resultado.get("dados") or dados

        # Atualiza os campos da tela principal.
        self.placa_var.set(
            dados_salvos.get("placa", placa)
        )
        self.motorista_var.set(
            dados_salvos.get("motorista", motorista)
        )
        dados_salvos.get("rg", rg_variavel)

        # Atualiza o card.
        self.card_placa_var.set(self.placa_var.get())
        self.card_motorista_var.set(self.motorista_var.get())

        self._mostrar_status(mensagem, design.SUCCESS)

        self._fechar_modal_motorista()

    def _atualizar_cards_apos_cadastro(self, dados_enviados, resultado):
        """Mantém nos cards os dados do último CT-e cadastrado."""
        dados_salvos = resultado.get("dados") or dados_enviados

        self.ultimo_cte_var.set(
            dados_salvos.get("numero_documento") or dados_salvos.get("numero_cte")
            or dados_enviados.get("numero_documento")
            or self.ultimo_cte_var.get()
        )
        self.cliente_var.set(
            dados_salvos.get("remetente")
            or dados_enviados.get("remetente")
            or self.cliente_var.get()
        )
        self.card_placa_var.set(
            dados_salvos.get("placa")
            or dados_enviados.get("placa")
            or "-"
        )
        self.card_motorista_var.set(
            dados_salvos.get("motorista")
            or dados_enviados.get("motorista")
            or "-"
        )

    def _limpar_formulario_principal(self):
        """Limpa o formulário somente após o cadastro bem-sucedido."""
        self.destinatario_var.set("")
        self.cidade_origem_var.set("")
        self.uf_origem_var.set("")
        self.cidade_destino_var.set("")
        self.uf_destino_var.set("")
        self.remetente_var.set("")
        self.codigo_var.set("")
        self.numero_documento_var.set("")
        self.placa_var.set("")
        self.motorista_var.set("")
        self.observacao_var.set("")
        self.data_var.set(self.placeholder_data)
        self.data_entry.configure(state="normal", style="TEntry")

        self.numero_documento_entry.configure(
            state="normal",
            style="TEntry",
        )
        self.motorista_entry.configure(
            state="readonly",
            style="Data.TEntry",
        )

        self.update_idletasks()
        self.codigo_entry.focus_set()

    # --------------------------------------------------------
    # RESULTADOS DA CONSULTA DE DOCUMENTOS
    # --------------------------------------------------------
    def _preencher_formulario(self, dados):
        """Preenche a tela principal com o documento selecionado."""
        if not isinstance(dados, dict):
            self._mostrar_status(
                "Os dados do documento são inválidos.",
                design.DANGER,
            )
            return

        self.destinatario_var.set(dados.get("destinatario", ""))
        # Preencher UF antes da cidade para não apagar o valor recuperado.
        self.uf_origem_var.set(dados.get("uf_origem", ""))
        self.cidade_origem_var.set(dados.get("cidade_origem", ""))
        self.uf_destino_var.set(dados.get("uf_destino", ""))
        self.cidade_destino_var.set(dados.get("cidade_destino", ""))
        self.remetente_var.set(dados.get("remetente", ""))
        self.codigo_var.set(dados.get("codigo_barras", ""))
        self.numero_documento_var.set(dados.get("numero_documento") or dados.get("numero_cte") or dados.get("numero_nf", ""))
        self.placa_var.set(dados.get("placa", ""))
        self.motorista_var.set(dados.get("motorista", ""))
        self.data_var.set(dados.get("data", ""))
        self.observacao_var.set(dados.get("observacao", ""))

        # Atualiza os cards com o documento carregado.
        self.ultimo_cte_var.set(dados.get("numero_documento") or dados.get("numero_cte") or dados.get("numero_nf") or "-")
        self.cliente_var.set(dados.get("remetente") or "-")
        self.card_placa_var.set(dados.get("placa") or "-")
        self.card_motorista_var.set(dados.get("motorista") or "-")

        # Dados encontrados no banco não devem ser alterados diretamente.
        self.numero_documento_entry.configure(
            state="readonly",
            style="Data.TEntry",
        )
        self.motorista_entry.configure(
            state="readonly",
            style="Data.TEntry",
        )

    def _abrir_modal_resultados(self, registros):
        """Exibe uma tabela quando a consulta encontra vários documentos."""
        if self.modal_resultados and self.modal_resultados.winfo_exists():
            self.modal_resultados.lift()
            self.modal_resultados.focus_force()
            return

        modal = tk.Toplevel(self)
        self.modal_resultados = modal

        modal.title("Resultados da consulta")
        modal.geometry("900x420")
        modal.minsize(720, 360)
        modal.configure(bg=design.WHITE)
        modal.transient(self)
        modal.grab_set()
        modal.protocol("WM_DELETE_WINDOW", self._fechar_modal_resultados)

        self._centralizar_modal(modal, 900, 420)

        container = tk.Frame(modal, bg=design.WHITE)
        container.pack(fill="both", expand=True, padx=20, pady=20)

        tk.Label(
            container,
            text=f"{len(registros)} documentos encontrados",
            **design.SECTION_TITLE_STYLE,
        ).pack(anchor="w", pady=(0, 12))

        # A tabela mostra somente os campos necessários para escolher.
        colunas = (
            "numero_cte",
            "remetente",
            "placa",
            "motorista",
            "data",
        )

        area_tabela = tk.Frame(container, bg=design.WHITE)
        area_tabela.pack(fill="both", expand=True)

        tabela = ttk.Treeview(
            area_tabela,
            columns=colunas,
            show="headings",
            selectmode="browse",
        )
        rolagem = ttk.Scrollbar(
            area_tabela,
            orient="vertical",
            command=tabela.yview,
        )
        tabela.configure(yscrollcommand=rolagem.set)

        tabela.heading("numero_cte", text="NF-e / CT-e")
        tabela.heading("remetente", text="Remetente")
        tabela.heading("placa", text="Placa")
        tabela.heading("motorista", text="Motorista")
        tabela.heading("data", text="Data")

        tabela.column("numero_cte", width=90, anchor="center")
        tabela.column("remetente", width=230)
        tabela.column("placa", width=100, anchor="center")
        tabela.column("motorista", width=180)
        tabela.column("data", width=100, anchor="center")

        tabela.pack(side="left", fill="both", expand=True)
        rolagem.pack(side="right", fill="y")

        # O iid guarda o índice do registro correspondente na lista.
        for indice, registro in enumerate(registros):
            tabela.insert(
                "",
                "end",
                iid=str(indice),
                values=(
                    (registro.get("tipo_documento", "CTE") + " " + (registro.get("numero_documento") or registro.get("numero_cte", ""))),
                    registro.get("remetente", ""),
                    registro.get("placa", ""),
                    registro.get("motorista", ""),
                    registro.get("data", ""),
                ),
            )

        def selecionar_documento(event=None):
            """Carrega o registro selecionado na tela principal."""
            selecionados = tabela.selection()

            if not selecionados:
                self._mostrar_status(
                    "Selecione um documento.",
                    design.DANGER,
                )
                return

            indice = int(selecionados[0])
            documento = registros[indice]

            # Preenche os campos da tela principal.
            self._preencher_formulario(documento)

            # Fecha somente o modal de resultados.
            self._fechar_modal_resultados()

            # Apaga a mensagem, mantendo os dados preenchidos.
            self.status_label.configure(text="")

            self.lift()
            self.remetente_entry.focus_set()

        # Fora da função, ainda dentro de _abrir_modal_resultados.
        tabela.bind("<Double-1>", selecionar_documento)
        tabela.bind("<Return>", selecionar_documento)

        botoes = tk.Frame(container, bg=design.WHITE)
        botoes.pack(fill="x", pady=(12, 0))
        tk.Button(botoes, text="Cancelar", command=self._fechar_modal_resultados,
                  **design.BUTTON_OUTLINE).pack(side="right", padx=(8, 0))
        tk.Button(botoes, text="Selecionar", command=selecionar_documento,
                  **design.BUTTON_PRIMARY).pack(side="right")
        if registros:
            tabela.selection_set("0")
            tabela.focus("0")
        tabela.focus_set()

    def _fechar_modal_resultados(self):

        """Fecha o modal de consulta e libera a janela principal."""
        if self.modal_resultados and self.modal_resultados.winfo_exists():
            self.modal_resultados.grab_release()
            self.modal_resultados.destroy()

        self.modal_resultados = None

    def _perguntar_nova_consulta(self):
        nova_consulta = messagebox.askyesno(
            "Nova consulta",
            "Deseja efetuar uma nova consulta?\n\n"
            "Sim: limpa o formulário.\n"
            "Não: mantém os dados.",
            parent=self,
        )

        if nova_consulta:
            self._limpar_formulario_principal()
            self.remetente_entry.focus_set()

        self.status_label.configure(text="")

    def criar_combobox_cliente(
            self,
            parent,
            titulo,
            textvariable,
            linha,
            coluna,
            quantidade_colunas=1,
            tipo="origem",
    ):
        """Cria Combobox com autocomplete e navegação por Tab/Enter."""

        # =====================================================
        # LAYOUT ORIGINAL
        # =====================================================

        bloco = tk.Frame(parent, bg=design.WHITE)

        bloco.grid(
            row=linha,
            column=coluna,
            columnspan=quantidade_colunas,
            sticky="ew",
            padx=design.FIELD_PAD_X,
            pady=(0, design.FIELD_PAD_BOTTOM),
        )

        tk.Label(
            bloco,
            text=titulo,
            font=design.FONT_LABEL,
            fg=design.TEXT,
            bg=design.WHITE,
        ).pack(anchor="w", pady=(0, 4))

        # =====================================================
        # CARREGAR CLIENTES
        # =====================================================

        try:
            clientes = self.controller.consultar_clientes()

        except Exception as erro:
            self._mostrar_status(
                f"Erro ao carregar clientes: {erro}",
                design.DANGER,
            )
            clientes = []

        opcoes = []
        mapa_clientes = {}

        for cliente in clientes:
            nome = str(cliente.get("nome", "") or "").strip()
            cidade = str(cliente.get("cidade", "") or "").strip()
            uf = str(cliente.get("uf", "") or "").strip().upper()

            if not nome:
                continue

            exibicao = nome

            if cidade and uf:
                exibicao = f"{nome} - {cidade}/{uf}"

            opcoes.append(exibicao)
            mapa_clientes[exibicao.casefold()] = cliente

        opcoes.sort(key=str.casefold)

        def recarregar_clientes():
            """Atualiza as opções sem reiniciar o aplicativo."""
            opcoes.clear()
            mapa_clientes.clear()
            for cliente in self.controller.consultar_clientes():
                nome = str(cliente.get("nome") or "").strip()
                cidade = str(cliente.get("cidade") or "").strip()
                uf = str(cliente.get("uf") or "").strip().upper()
                if nome:
                    exibicao = f"{nome} - {cidade}/{uf}" if cidade and uf else nome
                    opcoes.append(exibicao)
                    mapa_clientes[exibicao.casefold()] = cliente
            opcoes.sort(key=str.casefold)
            combo.configure(values=opcoes)

        self._atualizadores_clientes.append(recarregar_clientes)


        # =====================================================
        # COMBOBOX
        # =====================================================

        combo = ttk.Combobox(
            bloco,
            textvariable=textvariable,
            values=opcoes,
            state="normal",
            height=8,
        )

        combo.pack(fill="x")

        selecionando = False
        tarefa_dropdown = None
        resultados_atuais = []
        ultimo_cliente = None
        apagando = False

        # =====================================================
        # CANCELAR ABERTURA PENDENTE
        # =====================================================

        def cancelar_dropdown():
            nonlocal tarefa_dropdown

            if tarefa_dropdown is not None:
                try:
                    combo.after_cancel(tarefa_dropdown)
                except (tk.TclError, ValueError):
                    pass

                tarefa_dropdown = None

        # =====================================================
        # FECHAR DROPDOWN
        # =====================================================

        def fechar_dropdown():
            cancelar_dropdown()

            try:
                combo.tk.call(
                    "ttk::combobox::Unpost",
                    str(combo),
                )
            except tk.TclError:
                pass

        # =====================================================
        # ABRIR DROPDOWN
        # =====================================================

        def abrir_dropdown():
            nonlocal tarefa_dropdown

            tarefa_dropdown = None

            if selecionando or apagando:
                return

            if not resultados_atuais:
                return

            try:
                if combo.winfo_exists() and combo.focus_get() == combo:
                    combo.tk.call(
                        "ttk::combobox::Post",
                        str(combo),
                    )
            except tk.TclError:
                pass

        # =====================================================
        # FILTRAR CLIENTES
        # =====================================================

        def filtrar_clientes(event=None):
            nonlocal resultados_atuais
            nonlocal tarefa_dropdown
            nonlocal ultimo_cliente
            nonlocal apagando

            if selecionando:
                return

            cancelar_dropdown()

            # Backspace e Delete: não abre sugestões.
            if event is not None and event.keysym in (
                    "BackSpace",
                    "Delete",
            ):
                apagando = True
                resultados_atuais = []
                combo.configure(values=[])
                fechar_dropdown()
                ultimo_cliente = None
                return

            # Ignora teclas de navegação.
            if event is not None and event.keysym in (
                    "Tab",
                    "Return",
                    "KP_Enter",
                    "Up",
                    "Down",
                    "Left",
                    "Right",
                    "Escape",
                    "Shift_L",
                    "Shift_R",
                    "Control_L",
                    "Control_R",
            ):
                return

            apagando = False

            termo = textvariable.get().strip().casefold()

            if ultimo_cliente is not None:
                nome_anterior = str(
                    ultimo_cliente.get("nome", "") or ""
                ).strip().casefold()

                if termo != nome_anterior:
                    ultimo_cliente = None

            if len(termo) < 3:
                resultados_atuais = []
                combo.configure(values=[])
                fechar_dropdown()
                return

            resultados_atuais = [
                opcao
                for opcao in opcoes
                if opcao.casefold().startswith(termo)
            ]

            combo.configure(values=resultados_atuais)

            if resultados_atuais:
                tarefa_dropdown = combo.after(
                    80,
                    abrir_dropdown,
                )
            else:
                fechar_dropdown()

        # =====================================================
        # PREENCHER CLIENTE
        # =====================================================

        def preencher_cliente(cliente):
            nonlocal selecionando
            nonlocal ultimo_cliente
            nonlocal apagando

            nome = str(cliente.get("nome", "") or "").strip()
            cidade = str(cliente.get("cidade", "") or "").strip()
            uf = str(cliente.get("uf", "") or "").strip().upper()

            selecionando = True

            try:
                textvariable.set(nome)

                # A mudança da UF limpa a cidade no autocomplete.
                # Portanto, selecionar primeiro a UF e depois a cidade.
                if tipo == "origem":
                    self.uf_origem_var.set(uf)
                    self.cidade_origem_var.set(cidade)

                else:
                    self.uf_destino_var.set(uf)
                    self.cidade_destino_var.set(cidade)

                ultimo_cliente = cliente
                apagando = False

                combo.configure(values=opcoes)

            finally:
                selecionando = False

            fechar_dropdown()

        # =====================================================
        # LOCALIZAR CLIENTE
        # =====================================================

        def localizar_cliente():
            texto = textvariable.get().strip()
            chave = texto.casefold()

            if not texto:
                return None

            # Cliente selecionado diretamente no dropdown.
            cliente = mapa_clientes.get(chave)

            if cliente:
                return cliente

            # Cliente já selecionado anteriormente.
            if ultimo_cliente is not None:
                nome_anterior = str(
                    ultimo_cliente.get("nome", "") or ""
                ).strip()

                if chave == nome_anterior.casefold():
                    return ultimo_cliente

            # Busca o primeiro resultado correspondente.
            if len(chave) >= 3:
                encontrados = [
                    opcao
                    for opcao in opcoes
                    if opcao.casefold().startswith(chave)
                ]

                if encontrados:
                    return mapa_clientes[
                        encontrados[0].casefold()
                    ]

            return None

        # =====================================================
        # AVANÇAR PARA PRÓXIMO CAMPO
        # =====================================================

        def avancar_campo():
            try:
                proximo = combo.tk_focusNext()

                if proximo is not None:
                    proximo.focus_set()

            except tk.TclError:
                pass

        # =====================================================
        # SELECIONAR CLIENTE
        # =====================================================

        def selecionar_cliente(avancar=True):
            cliente = localizar_cliente()

            if cliente is None:
                fechar_dropdown()
                return False

            preencher_cliente(cliente)

            if avancar:
                combo.after_idle(avancar_campo)

            return True

        # =====================================================
        # TECLA TAB
        # =====================================================

        def ao_pressionar_tab(event=None):
            selecionar_cliente(avancar=False)

            combo.after_idle(avancar_campo)

            return "break"

        # =====================================================
        # TECLA ENTER
        # =====================================================

        def ao_pressionar_enter(event=None):
            selecionar_cliente(avancar=True)

            return "break"

        # =====================================================
        # CLIQUE NA LISTA
        # =====================================================

        def ao_selecionar_dropdown(event=None):
            selecionar_cliente(avancar=True)

        # =====================================================
        # EVENTOS
        # =====================================================

        combo.bind(
            "<KeyRelease>",
            filtrar_clientes,
        )

        combo.bind(
            "<<ComboboxSelected>>",
            ao_selecionar_dropdown,
        )

        combo.bind(
            "<Tab>",
            ao_pressionar_tab,
        )

        combo.bind(
            "<Return>",
            ao_pressionar_enter,
        )

        combo.bind(
            "<KP_Enter>",
            ao_pressionar_enter,
        )

        combo.bind(
            "<Escape>",
            lambda event: fechar_dropdown(),
        )

        return combo