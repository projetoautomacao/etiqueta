import csv
import io
import re
import sqlite3
from pathlib import Path


PASTA_PROJETO = Path(__file__).resolve().parent

CAMINHO_CSV = Path(
    r"C:\Users\Transanches\Desktop\controle_cadastro2"
    r"\ETIQUETA_DOWNLOAD\motoristas_normalizados.csv"
)

CAMINHO_BANCO = PASTA_PROJETO / "dados" / "etiquetas.db"


def ler_csv(caminho):
    """Lê o CSV tentando as codificações mais comuns."""

    codificacoes = (
        "utf-8-sig",
        "cp1252",
        "latin-1",
    )

    for codificacao in codificacoes:
        try:
            texto = caminho.read_text(encoding=codificacao)
            print(f"Codificação identificada: {codificacao}")
            return texto
        except UnicodeDecodeError:
            continue

    raise ValueError("Não foi possível identificar a codificação do CSV.")


def normalizar_nome(nome):
    nome = str(nome or "").strip()
    nome = re.sub(r"\s+", " ", nome)

    return nome.title()


def normalizar_rg(rg):
    rg = str(rg or "").strip().upper()

    # Remove pontos, espaços, traços e outros símbolos.
    return re.sub(r"[^A-Z0-9]", "", rg)


def normalizar_placa(placa):
    placa = str(placa or "").strip().upper()

    # Remove espaço, ponto, barra e hífen.
    placa = re.sub(r"[^A-Z0-9]", "", placa)

    if len(placa) == 7:
        return f"{placa[:3]}-{placa[3:]}"

    return placa


def placa_valida(placa):
    """
    Aceita:
    ABC-1234
    ABC-1D23
    """

    return bool(
        re.fullmatch(
            r"[A-Z]{3}-[0-9][A-Z0-9][0-9]{2}",
            placa,
        )
    )


def carregar_csv():
    texto = ler_csv(CAMINHO_CSV)

    try:
        formato = csv.Sniffer().sniff(
            texto[:4096],
            delimiters=",;",
        )
    except csv.Error:
        formato = csv.excel

    leitor = csv.DictReader(
        io.StringIO(texto),
        dialect=formato,
    )

    if not leitor.fieldnames:
        raise ValueError("O CSV não possui cabeçalho.")

    leitor.fieldnames = [
        campo.strip().lower()
        for campo in leitor.fieldnames
    ]

    colunas_necessarias = {"nome", "rg", "placa"}
    colunas_encontradas = set(leitor.fieldnames)
    colunas_faltantes = colunas_necessarias - colunas_encontradas

    if colunas_faltantes:
        raise ValueError(
            "Colunas ausentes: "
            + ", ".join(sorted(colunas_faltantes))
        )

    registros_por_placa = {}
    linhas_invalidas = []

    for numero_linha, registro in enumerate(leitor, start=2):
        nome = normalizar_nome(registro.get("nome"))
        rg = normalizar_rg(registro.get("rg"))
        placa = normalizar_placa(registro.get("placa"))

        if not nome:
            linhas_invalidas.append(
                f"Linha {numero_linha}: nome vazio."
            )
            continue

        if not placa_valida(placa):
            linhas_invalidas.append(
                f"Linha {numero_linha}: placa inválida "
                f"'{registro.get('placa', '')}'."
            )
            continue

        # Se a placa aparecer novamente, mantém o último registro.
        registros_por_placa[placa] = {
            "nome": nome,
            "rg": rg,
            "placa": placa,
        }

    return registros_por_placa, linhas_invalidas


def localizar_motorista(conexao, nome, rg):
    """
    Procura primeiro pelo RG.
    Caso o RG esteja vazio, procura pelo nome.
    """

    if rg:
        motorista = conexao.execute(
            """
            SELECT id, nome, rg
            FROM motoristas
            WHERE rg = ?
            ORDER BY id DESC
            LIMIT 1
            """,
            (rg,),
        ).fetchone()

        if motorista:
            return motorista

    return conexao.execute(
        """
        SELECT id, nome, rg
        FROM motoristas
        WHERE LOWER(TRIM(nome)) = LOWER(TRIM(?))
        ORDER BY id DESC
        LIMIT 1
        """,
        (nome,),
    ).fetchone()


def salvar_motorista(conexao, nome, rg):
    motorista = localizar_motorista(
        conexao=conexao,
        nome=nome,
        rg=rg,
    )

    if motorista:
        motorista_id = motorista["id"]

        conexao.execute(
            """
            UPDATE motoristas
            SET nome = ?, rg = ?
            WHERE id = ?
            """,
            (nome, rg, motorista_id),
        )

        return motorista_id, False

    cursor = conexao.execute(
        """
        INSERT INTO motoristas (nome, rg)
        VALUES (?, ?)
        """,
        (nome, rg),
    )

    return cursor.lastrowid, True


def salvar_veiculo(conexao, placa, motorista_id):
    veiculo = conexao.execute(
        """
        SELECT placa
        FROM veiculos
        WHERE placa = ?
        """,
        (placa,),
    ).fetchone()

    if veiculo:
        conexao.execute(
            """
            UPDATE veiculos
            SET motorista_id = ?
            WHERE placa = ?
            """,
            (motorista_id, placa),
        )

        return False

    conexao.execute(
        """
        INSERT INTO veiculos (placa, motorista_id)
        VALUES (?, ?)
        """,
        (placa, motorista_id),
    )

    return True


def importar_motoristas():
    if not CAMINHO_CSV.exists():
        print(f"CSV não encontrado: {CAMINHO_CSV}")
        return

    if not CAMINHO_BANCO.exists():
        print(f"Banco não encontrado: {CAMINHO_BANCO}")
        return

    registros, linhas_invalidas = carregar_csv()

    motoristas_novos = 0
    motoristas_atualizados = 0
    veiculos_novos = 0
    veiculos_atualizados = 0

    with sqlite3.connect(CAMINHO_BANCO) as conexao:
        conexao.row_factory = sqlite3.Row
        conexao.execute("PRAGMA foreign_keys = ON")

        for registro in registros.values():
            motorista_id, motorista_novo = salvar_motorista(
                conexao=conexao,
                nome=registro["nome"],
                rg=registro["rg"],
            )

            veiculo_novo = salvar_veiculo(
                conexao=conexao,
                placa=registro["placa"],
                motorista_id=motorista_id,
            )

            if motorista_novo:
                motoristas_novos += 1
            else:
                motoristas_atualizados += 1

            if veiculo_novo:
                veiculos_novos += 1
            else:
                veiculos_atualizados += 1

        conexao.commit()

    print()
    print("Importação concluída com sucesso.")
    print(f"Motoristas novos: {motoristas_novos}")
    print(f"Motoristas atualizados: {motoristas_atualizados}")
    print(f"Veículos novos: {veiculos_novos}")
    print(f"Veículos atualizados: {veiculos_atualizados}")
    print(f"Placas processadas: {len(registros)}")
    print(f"Linhas ignoradas: {len(linhas_invalidas)}")

    if linhas_invalidas:
        print()
        print("Linhas não importadas:")

        for erro in linhas_invalidas:
            print(f"- {erro}")


if __name__ == "__main__":
    importar_motoristas()