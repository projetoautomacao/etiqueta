if __package__:
    from .views.dashboard_view import DashboardCTe
else:
    from views.dashboard_view import DashboardCTe


def main():
    app = DashboardCTe()
    app.mainloop()


if __name__ == "__main__":
    main()
