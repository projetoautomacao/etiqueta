import csv
import re
from pathlib import Path


PASTA = Path(__file__).parent
CSV_ENTRADA = PASTA / "exp.csv"
CSV_SAIDA = PASTA / "motoristas_normalizados.csv"


def normalizar_nome(nome):
    """Remove espaços duplicados e padroniza o nome."""
    nome = str(nome or "").strip()
    nome = re.sub(r"\s+", " ", nome)

    return nome.title()


def normalizar_rg(rg):
    """
    Remove pontos, espaços e traços.
    Mantém números e possíveis letras, como X.
    """
    rg = str(rg or "").strip().upper()

    return re.sub(r"[^A-Z0-9]", "", rg)


def normalizar_placa(placa):
    """
    Converte a placa para o padrão AAA-1234 ou AAA-1B23.
    Aceita placas antigas e Mercosul.
    """
    placa = str(placa or "").strip().upper()
    placa = re.sub(r"[^A-Z0-9]", "", placa)

    if len(placa) == 7:
        return f"{placa[:3]}-{placa[3:]}"

    return placa


def normalizar_csv():
    # O dicionário mantém apenas o último registro de cada placa.
    registros_por_placa = {}

    with open(
        CSV_ENTRADA,
        mode="r",
        encoding="cp1252",
        newline="",
    ) as arquivo:
        #leitor = csv.DictReader(arquivo)
        leitor = csv.DictReader(arquivo, delimiter=";")

        campos_necessarios = {"nome", "rg", "placa"}

        if not leitor.fieldnames:
            raise ValueError("O CSV não possui cabeçalho.")

        cabecalho = {
            campo.strip().lower()
            for campo in leitor.fieldnames
        }

        campos_faltando = campos_necessarios - cabecalho

        if campos_faltando:
            raise ValueError(
                "Colunas ausentes no CSV: "
                + ", ".join(sorted(campos_faltando))
            )

        for numero_linha, registro in enumerate(leitor, start=2):
            # Padroniza os nomes das colunas.
            registro = {
                chave.strip().lower(): valor
                for chave, valor in registro.items()
                if chave
            }

            nome = normalizar_nome(registro.get("nome"))
            rg = normalizar_rg(registro.get("rg"))
            placa = normalizar_placa(registro.get("placa"))

            # Ignora linhas sem placa.
            if not placa:
                print(f"Linha {numero_linha} ignorada: placa vazia.")
                continue

            # A última ocorrência da placa substitui a anterior.
            registros_por_placa[placa] = {
                "nome": nome,
                "rg": rg,
                "placa": placa,
            }

    with open(
        CSV_SAIDA,
        mode="w",
        encoding="utf-8-sig",
        newline="",
    ) as arquivo:
        escritor = csv.DictWriter(
            arquivo,
            fieldnames=["nome", "rg", "placa"],
        )

        escritor.writeheader()
        escritor.writerows(registros_por_placa.values())

    print(f"Registros finais: {len(registros_por_placa)}")
    print(f"Arquivo criado: {CSV_SAIDA}")


if __name__ == "__main__":
    normalizar_csv()