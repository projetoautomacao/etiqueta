import re
import shutil
import sqlite3
from datetime import datetime
from pathlib import Path

import pandas as pd


# ============================================================
# CONFIGURAÇÃO
# ============================================================

PASTA_PROJETO = Path(__file__).resolve().parent

ARQUIVO_EXCEL = PASTA_PROJETO / "relatorio.xlsx"

BANCO_DADOS = (
    PASTA_PROJETO
    / "dados"
    / "controle_entrega.db"
)

PASTA_BACKUP = (
    PASTA_PROJETO
    / "backup_importacao"
)


# ============================================================
# NOMES DAS COLUNAS
# ============================================================

COL_MOTORISTA = "Motorista - Nome"
COL_RG = "Motorista - RG"

COL_NOME_REMETENTE = "Remetente - Nome"
COL_CIDADE_REMETENTE = "Remetente - Cidade"
COL_UF_REMETENTE = "Remetente - UF"
COL_CNPJ_REMETENTE = "Remetente - CNPJ/CPF"

COL_NOME_DESTINATARIO = "Destinatário - Nome"
COL_CIDADE_DESTINATARIO = "Destinatário - Cidade"
COL_UF_DESTINATARIO = "Destinatário - UF"
COL_CNPJ_DESTINATARIO = "Destinatário - CNPJ/CPF"

COL_PLACA = "Veículo - Placa"


COLUNAS_OBRIGATORIAS = [
    COL_MOTORISTA,
    COL_RG,

    COL_NOME_REMETENTE,
    COL_CIDADE_REMETENTE,
    COL_UF_REMETENTE,
    COL_CNPJ_REMETENTE,

    COL_NOME_DESTINATARIO,
    COL_CIDADE_DESTINATARIO,
    COL_UF_DESTINATARIO,
    COL_CNPJ_DESTINATARIO,

    COL_PLACA,
]


# ============================================================
# FUNÇÕES DE LIMPEZA
# ============================================================

def limpar_texto(valor):
    """
    Converte qualquer valor para texto e remove
    espaços desnecessários.
    """

    if valor is None:
        return ""

    if pd.isna(valor):
        return ""

    texto = str(valor).strip()

    if texto.lower() in {
        "nan",
        "none",
        "null",
        "<na>",
    }:
        return ""

    texto = re.sub(
        r"\s+",
        " ",
        texto,
    )

    return texto.strip()


# ============================================================
# NORMALIZAR CABEÇALHO DO EXCEL
# ============================================================

def normalizar_coluna(coluna):
    """
    Corrige espaços existentes nos cabeçalhos.

    Exemplos:

    Motorista   - Nome
        ->
    Motorista - Nome

    Remetente -   Cidade
        ->
    Remetente - Cidade
    """

    coluna = str(coluna)

    # NBSP do Excel
    coluna = coluna.replace(
        "\xa0",
        " ",
    )

    coluna = coluna.strip()

    # Vários espaços -> um
    coluna = re.sub(
        r"\s+",
        " ",
        coluna,
    )

    # Espaço padronizado no hífen
    coluna = re.sub(
        r"\s*-\s*",
        " - ",
        coluna,
    )

    return coluna.strip()


# ============================================================
# CPF / CNPJ
# ============================================================

def limpar_documento(valor):
    """
    Retorna somente números.

    Exemplo:

    12.345.678/0001-90
        ->
    12345678000190
    """

    texto = limpar_texto(valor)

    if not texto:
        return ""

    # Caso Excel tenha transformado em número decimal.
    texto = re.sub(
        r"\.0$",
        "",
        texto,
    )

    documento = re.sub(
        r"\D",
        "",
        texto,
    )

    return documento


# ============================================================
# RG
# ============================================================

def limpar_rg(valor):
    """
    Limpa espaços do RG.

    Não removemos letras porque alguns documentos
    podem possuir caracteres alfanuméricos.
    """

    rg = limpar_texto(valor)

    if not rg:
        return ""

    rg = re.sub(
        r"\.0$",
        "",
        rg,
    )

    return rg.strip()


# ============================================================
# LIMPEZA DO NOME DA EMPRESA
# ============================================================

def limpar_nome_empresa(valor):
    """
    Remove código existente antes do nome e
    categoria/tipo societário no final.

    Exemplo:

    010452/01 - TRANSANCHES TRANSPORTES LTDA

    Resultado:

    TRANSANCHES TRANSPORTES
    """

    nome = limpar_texto(valor)

    if not nome:
        return ""

    # --------------------------------------------------------
    # REMOVE CÓDIGO NO INÍCIO
    # --------------------------------------------------------
    #
    # Exemplos:
    #
    # 010452/01 - EMPRESA
    # 010452 - EMPRESA
    # 010452/01 EMPRESA
    # 010452 EMPRESA
    #

    nome = re.sub(
        r"^\s*\d+(?:[./-]\d+)*\s*[-–—:]?\s*",
        "",
        nome,
    )

    nome = nome.lstrip(
        " -–—:/"
    )

    # --------------------------------------------------------
    # REMOVE TIPO SOCIETÁRIO DO FINAL
    # --------------------------------------------------------

    tipos_empresa = [
        r"LTDA\.?",
        r"LIMITADA",
        r"MEI",
        r"ME",
        r"EPP",
        r"EIRELI",
        r"SLU",
        r"EI",
        r"S\s*/\s*A",
        r"S\.?\s*A\.?",
        r"SA",
    ]

    padrao = (
        r"[\s,.-]+(?:"
        + "|".join(tipos_empresa)
        + r")\s*$"
    )

    # Pode existir:
    #
    # EMPRESA LTDA ME
    #
    # então repetimos até não encontrar mais.
    while re.search(
        padrao,
        nome,
        flags=re.IGNORECASE,
    ):

        nome = re.sub(
            padrao,
            "",
            nome,
            flags=re.IGNORECASE,
        ).strip()

    nome = re.sub(
        r"\s+",
        " ",
        nome,
    )

    nome = nome.strip(
        " -–—,.;:/"
    )

    return nome


# ============================================================
# MOTORISTA
# ============================================================

def limpar_nome_motorista(valor):
    """
    Limpeza simples do nome do motorista.
    """

    nome = limpar_texto(valor)

    if not nome:
        return ""

    nome = re.sub(
        r"\s+",
        " ",
        nome,
    )

    return nome.strip()


# ============================================================
# CIDADE
# ============================================================

def limpar_cidade(valor):
    """
    Limpa a cidade.
    """

    cidade = limpar_texto(valor)

    cidade = re.sub(
        r"\s+",
        " ",
        cidade,
    )

    return cidade.strip()


# ============================================================
# UF
# ============================================================

def limpar_uf(valor):
    """
    Normaliza UF.

    pr -> PR
    Pr -> PR
    """

    uf = limpar_texto(valor)

    if not uf:
        return ""

    uf = uf.upper().strip()

    # Remove qualquer coisa que não seja letra.
    uf = re.sub(
        r"[^A-Z]",
        "",
        uf,
    )

    return uf


# ============================================================
# PLACA
# ============================================================

def normalizar_placa(valor):
    """
    Normaliza placa.

    ABC1234
        ->
    ABC-1234

    ABC1D23
        ->
    ABC-1D23
    """

    placa = limpar_texto(
        valor
    ).upper()

    if not placa:
        return ""

    placa = re.sub(
        r"[^A-Z0-9]",
        "",
        placa,
    )

    if len(placa) == 7:
        return (
            placa[:3]
            + "-"
            + placa[3:]
        )

    return placa


# ============================================================
# VALIDAR UF
# ============================================================

def uf_valida(uf):
    """
    Verifica se a UF possui exatamente duas letras.
    """

    return bool(
        re.fullmatch(
            r"[A-Z]{2}",
            uf,
        )
    )


# ============================================================
# BACKUP DO BANCO
# ============================================================

def criar_backup():
    """
    Cria uma cópia do banco antes da importação.
    """

    if not BANCO_DADOS.exists():
        raise FileNotFoundError(
            f"Banco não encontrado:\n{BANCO_DADOS}"
        )

    PASTA_BACKUP.mkdir(
        parents=True,
        exist_ok=True,
    )

    data_hora = datetime.now().strftime(
        "%Y%m%d_%H%M%S"
    )

    destino = (
        PASTA_BACKUP
        / f"etiquetas_{data_hora}.db"
    )

    shutil.copy2(
        BANCO_DADOS,
        destino,
    )

    print()
    print(
        f"Backup criado: {destino.name}"
    )


# ============================================================
# CARREGAR EXCEL
# ============================================================

def carregar_excel():
    """
    Abre o relatório e normaliza os cabeçalhos.
    """

    if not ARQUIVO_EXCEL.exists():

        raise FileNotFoundError(
            "\nArquivo Excel não encontrado:\n"
            f"{ARQUIVO_EXCEL}\n"
        )

    print()
    print("Lendo relatório...")

    df = pd.read_excel(
        ARQUIVO_EXCEL,
        dtype=str,
    )

    # --------------------------------------------------------
    # NORMALIZA CABEÇALHOS
    # --------------------------------------------------------

    df.columns = [
        normalizar_coluna(coluna)
        for coluna in df.columns
    ]

    # --------------------------------------------------------
    # CONFERE AS COLUNAS
    # --------------------------------------------------------

    faltando = [
        coluna
        for coluna in COLUNAS_OBRIGATORIAS
        if coluna not in df.columns
    ]

    if faltando:

        print()
        print("COLUNAS ENCONTRADAS:")
        print("-" * 60)

        for coluna in df.columns:
            print(
                repr(coluna)
            )

        print()

        raise ValueError(
            "As seguintes colunas não foram encontradas:\n"
            + "\n".join(
                f" - {coluna}"
                for coluna in faltando
            )
        )

    print(
        f"Linhas encontradas: {len(df)}"
    )

    return df


# ============================================================
# EXTRAIR CLIENTES
# ============================================================

def extrair_clientes(df):
    """
    Extrai remetentes e destinatários.

    CPF/CNPJ é usado para remover repetidos.

    Se o mesmo CPF/CNPJ aparecer novamente,
    a última informação encontrada será mantida.
    """

    clientes = {}

    ignorados = []

    def adicionar_cliente(
        linha_excel,
        origem,
        nome,
        cidade,
        uf,
        documento,
    ):

        nome = limpar_nome_empresa(
            nome
        )

        cidade = limpar_cidade(
            cidade
        )

        uf = limpar_uf(
            uf
        )

        documento = limpar_documento(
            documento
        )

        # ----------------------------------------------------
        # NOME
        # ----------------------------------------------------

        if not nome:

            ignorados.append({
                "linha": linha_excel,
                "origem": origem,
                "motivo": "Nome vazio",
            })

            return

        # ----------------------------------------------------
        # CPF/CNPJ
        # ----------------------------------------------------

        if not documento:

            ignorados.append({
                "linha": linha_excel,
                "origem": origem,
                "motivo": "CPF/CNPJ vazio",
            })

            return

        # ----------------------------------------------------
        # CIDADE
        # ----------------------------------------------------

        if not cidade:

            ignorados.append({
                "linha": linha_excel,
                "origem": origem,
                "motivo": "Cidade vazia",
            })

            return

        # ----------------------------------------------------
        # UF
        # ----------------------------------------------------

        if not uf_valida(uf):

            ignorados.append({
                "linha": linha_excel,
                "origem": origem,
                "motivo": (
                    "UF vazia ou inválida"
                ),
            })

            return

        # ----------------------------------------------------
        # CPF/CNPJ = CHAVE DO CLIENTE
        # ----------------------------------------------------
        #
        # Se aparecer novamente, substitui os dados anteriores.
        #

        clientes[documento] = {
            "nome": nome,
            "cpf_cnpj": documento,
            "cidade": cidade,
            "uf": uf,
        }

    # ========================================================
    # PERCORRER RELATÓRIO
    # ========================================================

    for indice, linha in df.iterrows():

        # Excel:
        # linha 1 = cabeçalho
        # dados começam na linha 2

        linha_excel = indice + 2

        # ----------------------------------------------------
        # REMETENTE
        # ----------------------------------------------------

        adicionar_cliente(
            linha_excel=linha_excel,
            origem="REMETENTE",
            nome=linha.get(
                COL_NOME_REMETENTE
            ),
            cidade=linha.get(
                COL_CIDADE_REMETENTE
            ),
            uf=linha.get(
                COL_UF_REMETENTE
            ),
            documento=linha.get(
                COL_CNPJ_REMETENTE
            ),
        )

        # ----------------------------------------------------
        # DESTINATÁRIO
        # ----------------------------------------------------

        adicionar_cliente(
            linha_excel=linha_excel,
            origem="DESTINATARIO",
            nome=linha.get(
                COL_NOME_DESTINATARIO
            ),
            cidade=linha.get(
                COL_CIDADE_DESTINATARIO
            ),
            uf=linha.get(
                COL_UF_DESTINATARIO
            ),
            documento=linha.get(
                COL_CNPJ_DESTINATARIO
            ),
        )

    return (
        list(clientes.values()),
        ignorados,
    )


# ============================================================
# EXTRAIR MOTORISTAS
# ============================================================

def extrair_motoristas(df):
    """
    Extrai motoristas sem repetição.

    RG é usado como chave principal.
    """

    motoristas = {}

    ignorados = []

    for indice, linha in df.iterrows():

        linha_excel = indice + 2

        nome = limpar_nome_motorista(
            linha.get(
                COL_MOTORISTA
            )
        )

        rg = limpar_rg(
            linha.get(
                COL_RG
            )
        )

        if not nome:
            continue

        if not rg:

            ignorados.append({
                "linha": linha_excel,
                "motivo": "Motorista sem RG",
            })

            continue

        # Última ocorrência do RG vence.
        motoristas[rg.casefold()] = {
            "nome": nome,
            "rg": rg,
        }

    return (
        list(motoristas.values()),
        ignorados,
    )


# ============================================================
# EXTRAIR PLACAS
# ============================================================

def extrair_placas(df):
    """
    Para cada placa mantém o ÚLTIMO motorista
    encontrado no relatório.

    Exemplo:

    ABC-1234 -> JOAO
    ABC-1234 -> CARLOS
    ABC-1234 -> MARCOS

    Resultado:

    ABC-1234 -> MARCOS
    """

    placas = {}

    for indice, linha in df.iterrows():

        linha_excel = indice + 2

        placa = normalizar_placa(
            linha.get(
                COL_PLACA
            )
        )

        motorista = limpar_nome_motorista(
            linha.get(
                COL_MOTORISTA
            )
        )

        rg = limpar_rg(
            linha.get(
                COL_RG
            )
        )

        if not placa:
            continue

        if not motorista:
            continue

        # Sobrescrever é proposital.
        #
        # Dessa maneira fica a última
        # ocorrência daquela placa.

        placas[placa] = {
            "linha": linha_excel,
            "placa": placa,
            "motorista": motorista,
            "rg": rg,
        }

    return list(
        placas.values()
    )


# ============================================================
# PROCURAR MOTORISTA NO BANCO
# ============================================================

def obter_motorista_id(
    conexao,
    nome,
    rg,
):
    """
    Primeiro procura pelo RG.
    Depois procura pelo nome.
    """

    # --------------------------------------------------------
    # RG
    # --------------------------------------------------------

    if rg:

        registro = conexao.execute(
            """
            SELECT id
            FROM motoristas
            WHERE rg = ?
            LIMIT 1
            """,
            (rg,),
        ).fetchone()

        if registro:
            return registro[0]

    # --------------------------------------------------------
    # NOME
    # --------------------------------------------------------

    if nome:

        registro = conexao.execute(
            """
            SELECT id
            FROM motoristas
            WHERE LOWER(TRIM(nome)) =
                  LOWER(TRIM(?))
            LIMIT 1
            """,
            (nome,),
        ).fetchone()

        if registro:
            return registro[0]

    return None


# ============================================================
# IMPORTAR CLIENTES
# ============================================================

def importar_clientes(
    conexao,
    clientes,
):
    """
    Insere novos clientes e atualiza os já existentes.
    """

    inseridos = 0
    atualizados = 0
    erros = []

    for cliente in clientes:

        try:

            documento = cliente[
                "cpf_cnpj"
            ]

            # ------------------------------------------------
            # VERIFICA SE JÁ EXISTE
            # ------------------------------------------------

            existente = conexao.execute(
                """
                SELECT id
                FROM clientes
                WHERE cpf_cnpj = ?
                LIMIT 1
                """,
                (documento,),
            ).fetchone()

            # ------------------------------------------------
            # ATUALIZAR
            # ------------------------------------------------

            if existente:

                conexao.execute(
                    """
                    UPDATE clientes
                    SET
                        nome = ?,
                        cidade = ?,
                        uf = ?
                    WHERE id = ?
                    """,
                    (
                        cliente["nome"],
                        cliente["cidade"],
                        cliente["uf"],
                        existente[0],
                    ),
                )

                atualizados += 1

            # ------------------------------------------------
            # INSERIR
            # ------------------------------------------------

            else:

                conexao.execute(
                    """
                    INSERT INTO clientes
                    (
                        nome,
                        cpf_cnpj,
                        cidade,
                        uf
                    )
                    VALUES (?, ?, ?, ?)
                    """,
                    (
                        cliente["nome"],
                        cliente["cpf_cnpj"],
                        cliente["cidade"],
                        cliente["uf"],
                    ),
                )

                inseridos += 1

        except sqlite3.Error as erro:

            erros.append(
                str(erro)
            )

    return {
        "inseridos": inseridos,
        "atualizados": atualizados,
        "erros": erros,
    }


# ============================================================
# IMPORTAR MOTORISTAS
# ============================================================

def importar_motoristas(
    conexao,
    motoristas,
):
    """
    Insere motoristas que ainda não existem.
    """

    inseridos = 0
    existentes = 0
    erros = []

    for motorista in motoristas:

        try:

            motorista_id = obter_motorista_id(
                conexao,
                motorista["nome"],
                motorista["rg"],
            )

            if motorista_id:

                existentes += 1
                continue

            conexao.execute(
                """
                INSERT INTO motoristas
                (
                    nome,
                    rg
                )
                VALUES (?, ?)
                """,
                (
                    motorista["nome"],
                    motorista["rg"],
                ),
            )

            inseridos += 1

        except sqlite3.Error as erro:

            erros.append(
                str(erro)
            )

    return {
        "inseridos": inseridos,
        "existentes": existentes,
        "erros": erros,
    }


# ============================================================
# IMPORTAR VEÍCULOS
# ============================================================

def importar_veiculos(
    conexao,
    placas,
):
    """
    Insere placas novas.

    Se a placa já existir, atualiza motorista_id
    para o último motorista encontrado no relatório.
    """

    inseridos = 0
    atualizados = 0
    ignorados = 0
    erros = []

    for item in placas:

        try:

            motorista_id = obter_motorista_id(
                conexao,
                item["motorista"],
                item["rg"],
            )

            # ------------------------------------------------
            # MOTORISTA NÃO EXISTE
            # ------------------------------------------------

            if motorista_id is None:

                ignorados += 1

                erros.append(
                    (
                        f"Linha {item['linha']}: "
                        f"motorista da placa "
                        f"{item['placa']} não encontrado."
                    )
                )

                continue

            # ------------------------------------------------
            # VERIFICA PLACA
            # ------------------------------------------------

            existente = conexao.execute(
                """
                SELECT placa
                FROM veiculos
                WHERE placa = ?
                LIMIT 1
                """,
                (item["placa"],),
            ).fetchone()

            # ------------------------------------------------
            # ATUALIZA
            # ------------------------------------------------

            if existente:

                conexao.execute(
                    """
                    UPDATE veiculos
                    SET motorista_id = ?
                    WHERE placa = ?
                    """,
                    (
                        motorista_id,
                        item["placa"],
                    ),
                )

                atualizados += 1

            # ------------------------------------------------
            # INSERE
            # ------------------------------------------------

            else:

                conexao.execute(
                    """
                    INSERT INTO veiculos
                    (
                        placa,
                        motorista_id
                    )
                    VALUES (?, ?)
                    """,
                    (
                        item["placa"],
                        motorista_id,
                    ),
                )

                inseridos += 1

        except sqlite3.Error as erro:

            erros.append(
                str(erro)
            )

    return {
        "inseridos": inseridos,
        "atualizados": atualizados,
        "ignorados": ignorados,
        "erros": erros,
    }


# ============================================================
# MOSTRAR CLIENTES IGNORADOS
# ============================================================

def mostrar_clientes_ignorados(
    ignorados,
):
    """
    Mostra somente linha/origem/motivo.
    Não imprime nomes nem documentos.
    """

    if not ignorados:
        return

    print()
    print(
        "CLIENTES NÃO PROCESSADOS"
    )

    print("-" * 60)

    # Mostra no máximo os primeiros 20.
    for item in ignorados[:20]:

        print(
            f"Linha {item['linha']} | "
            f"{item['origem']} | "
            f"{item['motivo']}"
        )

    if len(ignorados) > 20:

        print(
            f"... e mais "
            f"{len(ignorados) - 20} ocorrência(s)."
        )


# ============================================================
# MAIN
# ============================================================

def main():

    print()
    print("=" * 60)
    print("IMPORTADOR DO RELATÓRIO")
    print("=" * 60)

    # --------------------------------------------------------
    # 1 - LER EXCEL
    # --------------------------------------------------------

    df = carregar_excel()

    # --------------------------------------------------------
    # 2 - PROCESSAR CLIENTES
    # --------------------------------------------------------

    (
        clientes,
        clientes_ignorados,
    ) = extrair_clientes(
        df
    )

    # --------------------------------------------------------
    # 3 - PROCESSAR MOTORISTAS
    # --------------------------------------------------------

    (
        motoristas,
        motoristas_ignorados,
    ) = extrair_motoristas(
        df
    )

    # --------------------------------------------------------
    # 4 - PROCESSAR PLACAS
    # --------------------------------------------------------

    placas = extrair_placas(
        df
    )

    # --------------------------------------------------------
    # RESULTADO ANTES DO BANCO
    # --------------------------------------------------------

    print()
    print("DADOS ENCONTRADOS")
    print("-" * 60)

    print(
        f"Clientes únicos:   {len(clientes)}"
    )

    print(
        f"Motoristas únicos: {len(motoristas)}"
    )

    print(
        f"Placas únicas:     {len(placas)}"
    )

    print(
        f"Clientes ignorados: {len(clientes_ignorados)}"
    )

    print(
        f"Motoristas ignorados: "
        f"{len(motoristas_ignorados)}"
    )

    # --------------------------------------------------------
    # IMPORTANTE
    #
    # Se clientes == 0, não mexemos no banco.
    # --------------------------------------------------------

    if not clientes:

        mostrar_clientes_ignorados(
            clientes_ignorados
        )

        raise RuntimeError(
            "\nNenhum cliente válido foi encontrado "
            "no relatório.\n"
            "A importação foi cancelada."
        )

    # --------------------------------------------------------
    # 5 - BACKUP
    # --------------------------------------------------------

    criar_backup()

    # --------------------------------------------------------
    # 6 - ABRIR BANCO
    # --------------------------------------------------------

    with sqlite3.connect(
        BANCO_DADOS
    ) as conexao:

        try:

            # ------------------------------------------------
            # CLIENTES
            # ------------------------------------------------

            resultado_clientes = (
                importar_clientes(
                    conexao,
                    clientes,
                )
            )

            # ------------------------------------------------
            # MOTORISTAS
            # ------------------------------------------------

            resultado_motoristas = (
                importar_motoristas(
                    conexao,
                    motoristas,
                )
            )

            # ------------------------------------------------
            # VEÍCULOS
            # ------------------------------------------------

            resultado_veiculos = (
                importar_veiculos(
                    conexao,
                    placas,
                )
            )

            # ------------------------------------------------
            # SALVA TUDO
            # ------------------------------------------------

            conexao.commit()

        except Exception:

            conexao.rollback()

            raise

    # ========================================================
    # RESULTADO FINAL
    # ========================================================

    print()
    print("=" * 60)
    print("IMPORTAÇÃO CONCLUÍDA")
    print("=" * 60)

    print()
    print("CLIENTES")
    print("-" * 60)

    print(
        "Inseridos:",
        resultado_clientes[
            "inseridos"
        ],
    )

    print(
        "Atualizados:",
        resultado_clientes[
            "atualizados"
        ],
    )

    print(
        "Erros:",
        len(
            resultado_clientes[
                "erros"
            ]
        ),
    )

    print()
    print("MOTORISTAS")
    print("-" * 60)

    print(
        "Inseridos:",
        resultado_motoristas[
            "inseridos"
        ],
    )

    print(
        "Já existentes:",
        resultado_motoristas[
            "existentes"
        ],
    )

    print(
        "Erros:",
        len(
            resultado_motoristas[
                "erros"
            ]
        ),
    )

    print()
    print("VEÍCULOS")
    print("-" * 60)

    print(
        "Inseridos:",
        resultado_veiculos[
            "inseridos"
        ],
    )

    print(
        "Atualizados:",
        resultado_veiculos[
            "atualizados"
        ],
    )

    print(
        "Ignorados:",
        resultado_veiculos[
            "ignorados"
        ],
    )

    print(
        "Erros:",
        len(
            resultado_veiculos[
                "erros"
            ]
        ),
    )

    # --------------------------------------------------------
    # CLIENTES IGNORADOS
    # --------------------------------------------------------

    mostrar_clientes_ignorados(
        clientes_ignorados
    )

    # --------------------------------------------------------
    # ERROS DO SQLITE
    # --------------------------------------------------------

    if resultado_clientes["erros"]:

        print()
        print(
            "ERROS AO GRAVAR CLIENTES:"
        )

        for erro in set(
            resultado_clientes[
                "erros"
            ]
        ):
            print(
                " -",
                erro,
            )

    if resultado_motoristas["erros"]:

        print()
        print(
            "ERROS AO GRAVAR MOTORISTAS:"
        )

        for erro in set(
            resultado_motoristas[
                "erros"
            ]
        ):
            print(
                " -",
                erro,
            )

    if resultado_veiculos["erros"]:

        print()
        print(
            "ERROS AO GRAVAR VEÍCULOS:"
        )

        for erro in resultado_veiculos[
            "erros"
        ][:20]:

            print(
                " -",
                erro,
            )

    print()
    print("=" * 60)
    print("FINALIZADO")
    print("=" * 60)


# ============================================================
# EXECUTAR
# ============================================================

if __name__ == "__main__":

    try:

        main()

    except Exception as erro:

        print()
        print("=" * 60)
        print("ERRO NA IMPORTAÇÃO")
        print("=" * 60)

        print(
            erro
        )

        print()