

import sqlite3

from contextlib import contextmanager
from pathlib import Path
from datetime import datetime


class SQLiteRepository:
    """Repositório responsável pelo acesso ao banco SQLite."""

    def __init__(self, caminho=None):
        self.caminho = (
            Path(caminho)
            if caminho
            else Path(__file__).resolve().parents[1]
            / "dados"
            / "controle_entrega.db"
        )

        self.caminho.parent.mkdir(
            parents=True,
            exist_ok=True,
        )

        # Cria as tabelas caso ainda não existam.
        with self.conectar() as con:
            con.executescript(
                """
                CREATE TABLE IF NOT EXISTS motoristas (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    nome TEXT NOT NULL,
                    rg TEXT UNIQUE
                );

                CREATE TABLE IF NOT EXISTS clientes (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    nome TEXT NOT NULL,
                    cpf_cnpj TEXT UNIQUE NOT NULL,
                    cidade TEXT NOT NULL,
                    uf TEXT NOT NULL
                        CHECK (
                            length(uf) = 2
                            AND uf = upper(uf)
                        )
                );

                CREATE TABLE IF NOT EXISTS veiculos (
                    placa TEXT PRIMARY KEY,
                    motorista_id INTEGER NOT NULL,

                    FOREIGN KEY (motorista_id)
                        REFERENCES motoristas(id)
                );

                CREATE TABLE IF NOT EXISTS documentos (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,

                    id_remetente INTEGER,
                    id_destinatario INTEGER,

                    codigo_barras TEXT NOT NULL UNIQUE,

                    numero_cte TEXT NOT NULL DEFAULT '',
                    numero_nf TEXT NOT NULL DEFAULT '',

                    tipo_documento TEXT NOT NULL DEFAULT '',
                    numero_documento TEXT NOT NULL DEFAULT '',

                    remetente TEXT NOT NULL DEFAULT '',
                    destinatario TEXT NOT NULL DEFAULT '',

                    cidade_origem TEXT NOT NULL DEFAULT '',
                    uf_origem TEXT NOT NULL DEFAULT '',

                    cidade_destino TEXT NOT NULL DEFAULT '',
                    uf_destino TEXT NOT NULL DEFAULT '',

                    placa TEXT NOT NULL,
                    motorista TEXT NOT NULL DEFAULT '',
                    motorista_id INTEGER,

                    data TEXT NOT NULL DEFAULT '',
                    observacao TEXT NOT NULL DEFAULT '',

                    FOREIGN KEY (id_remetente)
                        REFERENCES clientes(id),

                    FOREIGN KEY (id_destinatario)
                        REFERENCES clientes(id),

                    FOREIGN KEY (placa)
                        REFERENCES veiculos(placa),

                    FOREIGN KEY (motorista_id)
                        REFERENCES motoristas(id)
                );

                """
            )

        # Atualiza bancos criados em versões anteriores.
        self._migrar_documentos()

    # ==========================================================
    # CONEXÃO
    # ==========================================================

    @contextmanager
    def conectar(self):
        """Abre uma conexão SQLite com configurações padrão."""

        con = sqlite3.connect(
            self.caminho,
            timeout=10,
        )

        con.row_factory = sqlite3.Row

        # Ativa as chaves estrangeiras.
        con.execute(
            "PRAGMA foreign_keys = ON"
        )

        # Função utilizada nas consultas de texto.
        con.create_function(
            "MAIUSCULA",
            1,
            lambda valor: str(valor or "").upper(),
        )

        try:
            with con:
                yield con

        finally:
            con.close()

    # ==========================================================
    # MIGRAÇÃO
    # ==========================================================

    def _migrar_documentos(self):
        """
        Atualiza bancos antigos sem apagar os dados existentes.

        Antes de alterar a estrutura do banco é criado um backup.
        """

        with self.conectar() as con:

            # --------------------------------------------------
            # MOTORISTAS
            # --------------------------------------------------

            colunas_motoristas = {
                linha["name"]
                for linha in con.execute(
                    "PRAGMA table_info(motoristas)"
                )
            }

            if "rg" not in colunas_motoristas:

                con.execute(
                    """
                    ALTER TABLE motoristas
                    ADD COLUMN rg TEXT
                    """
                )

            # --------------------------------------------------
            # DOCUMENTOS
            # --------------------------------------------------

            colunas_documentos = {
                linha["name"]
                for linha in con.execute(
                    "PRAGMA table_info(documentos)"
                )
            }

            novos_campos = {
                "numero_nf": "TEXT NOT NULL DEFAULT ''",
                "tipo_documento": "TEXT NOT NULL DEFAULT ''",
                "numero_documento": "TEXT NOT NULL DEFAULT ''",
                "remetente": "TEXT NOT NULL DEFAULT ''",
                "destinatario": "TEXT NOT NULL DEFAULT ''",
                "cidade_origem": "TEXT NOT NULL DEFAULT ''",
                "uf_origem": "TEXT NOT NULL DEFAULT ''",
                "cidade_destino": "TEXT NOT NULL DEFAULT ''",
                "uf_destino": "TEXT NOT NULL DEFAULT ''",
                "motorista": "TEXT NOT NULL DEFAULT ''",
                "motorista_id": "INTEGER",
            }

            faltantes = [
                campo
                for campo in novos_campos
                if campo not in colunas_documentos
            ]

            # --------------------------------------------------
            # BACKUP
            # --------------------------------------------------

            if faltantes:

                backup = self.caminho.with_name(
                    self.caminho.name
                    + ".backup_"
                    + datetime.now().strftime(
                        "%Y%m%d_%H%M%S_%f"
                    )
                )

                with sqlite3.connect(backup) as destino:
                    con.backup(destino)

                # --------------------------------------------------
                # ALTERAÇÃO ESTRUTURAL
                # --------------------------------------------------

                con.execute("BEGIN IMMEDIATE")

                for campo in faltantes:

                    con.execute(
                        f"""
                        ALTER TABLE documentos
                        ADD COLUMN {campo}
                        {novos_campos[campo]}
                        """
                    )

            # --------------------------------------------------
            # MIGRAÇÃO DOS DOCUMENTOS ANTIGOS
            # --------------------------------------------------

            colunas_documentos = {
                linha["name"]
                for linha in con.execute(
                    "PRAGMA table_info(documentos)"
                )
            }

            # Se existir numero_cte, utiliza-o para preencher
            # numero_documento dos registros antigos.

            if (
                "numero_documento" in colunas_documentos
                and "numero_cte" in colunas_documentos
                and "codigo_barras" in colunas_documentos
            ):

                con.execute(
                    """
                    UPDATE documentos
                    SET numero_documento =
                        CASE
                            WHEN numero_cte != ''
                                THEN numero_cte

                            ELSE
                                COALESCE(
                                    NULLIF(
                                        ltrim(
                                            substr(
                                                codigo_barras,
                                                26,
                                                9
                                            ),
                                            '0'
                                        ),
                                        ''
                                    ),
                                    '0'
                                )
                        END
                    WHERE numero_documento = ''
                    """
                )

            # --------------------------------------------------
            # IDENTIFICA NFE / CTE
            # --------------------------------------------------

            if (
                "tipo_documento" in colunas_documentos
                and "codigo_barras" in colunas_documentos
            ):

                con.execute(
                    """
                    UPDATE documentos
                    SET tipo_documento =
                        CASE
                            WHEN substr(codigo_barras, 21, 2) = '55'
                                THEN 'NFE'
                            ELSE 'CTE'
                        END
                    WHERE tipo_documento = ''
                    """
                )

            # --------------------------------------------------
            # NFE
            # --------------------------------------------------

            if (
                "numero_nf" in colunas_documentos
                and "numero_documento" in colunas_documentos
            ):

                con.execute(
                    """
                    UPDATE documentos
                    SET numero_nf = numero_documento,
                        numero_cte = ''
                    WHERE tipo_documento = 'NFE'
                      AND numero_nf = ''
                    """
                )

            # --------------------------------------------------
            # ÍNDICES
            # --------------------------------------------------

            for nome_indice, coluna in (
                ("idx_documentos_cte", "numero_cte"),
                ("idx_documentos_nf", "numero_nf"),
                ("idx_documentos_numero", "numero_documento"),
                ("idx_documentos_placa", "placa"),
                ("idx_documentos_motorista", "motorista"),
                ("idx_documentos_tipo", "tipo_documento"),
            ):
                con.execute(
                    f"CREATE INDEX IF NOT EXISTS {nome_indice} ON documentos({coluna})"
                )

    # ==========================================================
    # CLIENTES
    # ==========================================================

    def consultar_clientes(self):
        """Retorna clientes cadastrados sem repetir nomes."""

        with self.conectar() as con:

            registros = con.execute(
                """
                SELECT nome, cidade, uf
                FROM clientes
                ORDER BY nome
                """
            ).fetchall()

        clientes = {}

        for registro in registros:

            nome = (
                registro["nome"] or ""
            ).strip()

            cidade = (
                registro["cidade"] or ""
            ).strip()

            uf = (
                registro["uf"] or ""
            ).strip().upper()

            if nome:

                clientes.setdefault(
                    nome.casefold(),
                    {
                        "nome": nome,
                        "cidade": cidade,
                        "uf": uf,
                    },
                )

        return sorted(
            clientes.values(),
            key=lambda cliente:
                cliente["nome"].casefold(),
        )

    # Mantém o nome antigo para não quebrar
    # código existente no projeto.
    def conultarClientes(self):
        """Compatibilidade com o método antigo."""

        return self.consultar_clientes()

    # ==========================================================
    # MOTORISTAS
    # ==========================================================

    def listar_motoristas(self):
        """
        Retorna os motoristas cadastrados sem repetição.

        Cada motorista possui:
            nome
            rg
        """

        with self.conectar() as con:

            registros = con.execute(
                """
                SELECT nome, rg
                FROM motoristas
                ORDER BY nome
                """
            ).fetchall()

        motoristas = {}

        for registro in registros:

            nome = (
                registro["nome"] or ""
            ).strip()

            rg = (
                registro["rg"] or ""
            ).strip()

            if nome:

                motoristas.setdefault(
                    nome.casefold(),
                    {
                        "nome": nome,
                        "rg": rg,
                    },
                )

        return sorted(
            motoristas.values(),
            key=lambda motorista:
                motorista["nome"].casefold(),
        )

    # ==========================================================
    # CONSULTAR MOTORISTA PELA PLACA
    # ==========================================================

    def consultar_motorista(self, placa):
        """Consulta o motorista atualmente vinculado à placa."""

        placa = (
            placa or ""
        ).strip().upper()

        if not placa:
            return None

        with self.conectar() as con:

            row = con.execute(
                """
                SELECT
                    v.placa,
                    m.id AS motorista_id,
                    m.nome AS motorista,
                    m.rg AS rg
                FROM veiculos v

                INNER JOIN motoristas m
                    ON m.id = v.motorista_id

                WHERE v.placa = ?
                """,
                (placa,),
            ).fetchone()

        return dict(row) if row else None

    # ==========================================================
    # SALVAR MOTORISTA / PLACA
    # ==========================================================

    def salvar_motorista(
        self,
        placa,
        motorista,
        rg="",
    ):
        """
        Vincula uma placa a um motorista existente
        ou cadastra um novo motorista.

        Retorna:
            True  -> placa já existia e foi atualizada.
            False -> placa foi cadastrada.
        """

        placa = (
            placa or ""
        ).strip().upper()

        motorista = (
            motorista or ""
        ).strip()

        rg = (
            rg or ""
        ).strip()

        if not placa:
            raise ValueError(
                "A placa é obrigatória."
            )

        if not motorista:
            raise ValueError(
                "O nome do motorista é obrigatório."
            )

        with self.conectar() as con:

            con.execute(
                "BEGIN IMMEDIATE"
            )

            # --------------------------------------------------
            # VERIFICA SE A PLACA JÁ EXISTE
            # --------------------------------------------------

            veiculo = con.execute(
                """
                SELECT motorista_id
                FROM veiculos
                WHERE placa = ?
                """,
                (placa,),
            ).fetchone()

            # --------------------------------------------------
            # PROCURA MOTORISTA EXISTENTE
            # --------------------------------------------------

            # SQLite lower() não trata corretamente todos os caracteres
            # acentuados (ex.: João/JOÃO). A comparação em Python com
            # casefold() preserva um único cadastro para o mesmo motorista.
            motorista_existente = next(
                (
                    registro
                    for registro in con.execute(
                        "SELECT id, nome, rg FROM motoristas ORDER BY id"
                    ).fetchall()
                    if (registro["nome"] or "").strip().casefold()
                    == motorista.casefold()
                ),
                None,
            )

            # --------------------------------------------------
            # MOTORISTA EXISTENTE
            # --------------------------------------------------

            if motorista_existente:

                motorista_id = (
                    motorista_existente["id"]
                )

            # --------------------------------------------------
            # NOVO MOTORISTA
            # --------------------------------------------------

            else:

                cursor = con.execute(
                    """
                    INSERT INTO motoristas (
                        nome,
                        rg
                    )
                    VALUES (?, ?)
                    """,
                    (
                        motorista,
                        rg or None,
                    ),
                )

                motorista_id = (
                    cursor.lastrowid
                )

            # --------------------------------------------------
            # ATUALIZA PLACA
            # --------------------------------------------------

            if veiculo:

                con.execute(
                    """
                    UPDATE veiculos
                    SET motorista_id = ?
                    WHERE placa = ?
                    """,
                    (
                        motorista_id,
                        placa,
                    ),
                )

            # --------------------------------------------------
            # CADASTRA PLACA
            # --------------------------------------------------

            else:

                con.execute(
                    """
                    INSERT INTO veiculos (
                        placa,
                        motorista_id
                    )
                    VALUES (?, ?)
                    """,
                    (
                        placa,
                        motorista_id,
                    ),
                )

            return veiculo is not None

    # ==========================================================
    # DOCUMENTOS
    # ==========================================================

    def cadastrar_documento(self, dados):
        """
        Cadastra um documento.

        O método aceita o dicionário utilizado
        pelo restante do projeto.
        """

        campos = (
            "remetente",
            "codigo_barras",
            "numero_cte",
            "numero_nf",
            "tipo_documento",
            "numero_documento",
            "destinatario",
            "cidade_origem",
            "uf_origem",
            "cidade_destino",
            "uf_destino",
            "placa",
            "motorista",
            "data",
            "observacao",
        )

        valores = [
            dados.get(campo, "")
            for campo in campos
        ]

        with self.conectar() as con:

            cur = con.execute(
                f"""
                INSERT INTO documentos (
                    {", ".join(campos)}
                )
                VALUES (
                    {", ".join("?" for _ in campos)}
                )
                """,
                valores,
            )

            return {
                "id": cur.lastrowid,
                **dados,
            }

    # ==========================================================
    # CONSULTAR DOCUMENTOS
    # ==========================================================

    def consultar_documentos(self, filtros):
        """
        Consulta documentos utilizando os filtros informados.

        Campos de texto permitem pesquisa parcial.
        """

        clausulas = []
        valores = []

        campos_texto = {
            "remetente",
            "motorista",
            "destinatario",
            "cidade_origem",
            "cidade_destino",
        }

        campos_validos = {
            "remetente",
            "codigo_barras",
            "numero_cte",
            "numero_nf",
            "numero_documento",
            "tipo_documento",
            "destinatario",
            "cidade_origem",
            "uf_origem",
            "cidade_destino",
            "uf_destino",
            "placa",
            "motorista",
        }

        for campo, valor in filtros.items():

            if campo not in campos_validos:
                continue

            if valor is None:
                continue

            valor = str(valor).strip()

            if not valor:
                continue

            if campo in campos_texto:

                clausulas.append(
                    f"""
                    instr(
                        MAIUSCULA({campo}),
                        MAIUSCULA(?)
                    ) > 0
                    """
                )

                valores.append(valor)

            else:

                clausulas.append(
                    f"{campo} = ?"
                )

                valores.append(valor)

        # Nenhum filtro informado.
        if not clausulas:
            return []

        sql = """
            SELECT *
            FROM documentos
            WHERE
        """

        sql += " AND ".join(clausulas)

        sql += """
            ORDER BY id DESC
        """

        with self.conectar() as con:

            rows = con.execute(
                sql,
                valores,
            ).fetchall()

        return [
            dict(row)
            for row in rows
        ]
