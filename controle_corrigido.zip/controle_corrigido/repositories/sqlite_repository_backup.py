"""Persistência SQLite; conexões fechadas depois de cada operação."""
import sqlite3
from contextlib import contextmanager
from pathlib import Path


class SQLiteRepository:
    def __init__(self, caminho=None):
        self.caminho = Path(caminho) if caminho else Path(__file__).resolve().parents[1] / 'dados' / 'etiquetas.db'
        self.caminho.parent.mkdir(parents=True, exist_ok=True)
        with self.conectar() as con:
            con.executescript('''
                                CREATE TABLE IF NOT EXISTS motoristas (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    nome TEXT NOT NULL,
                    rg TEXT NOT NULL UNIQUE
                );
                
                CREATE TABLE IF NOT EXISTS clientes (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    nome TEXT NOT NULL,
                    cpf_cnpj TEXT UNIQUE NOT NULL,
                    cidade TEXT NOT NULL,
                    uf TEXT NOT NULL
                        CHECK (
                            length(uf) = 2
                            AND uf = upper(uf)
                        )
                );
                
                CREATE TABLE IF NOT EXISTS veiculos (
                    placa TEXT PRIMARY KEY,
                    motorista_id INTEGER NOT NULL,
                    FOREIGN KEY (motorista_id)
                        REFERENCES motoristas(id)
                );
                
                CREATE TABLE IF NOT EXISTS documentos (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                
                    id_remetente INTEGER NOT NULL,
                    id_destinatario INTEGER NOT NULL,
                
                    codigo_barras TEXT NOT NULL UNIQUE,
                    numero_cte TEXT NOT NULL,
                
                    placa TEXT NOT NULL,
                    motorista_id INTEGER NOT NULL,
                
                    data TEXT NOT NULL,
                    observacao TEXT NOT NULL DEFAULT '',
                
                    FOREIGN KEY (id_remetente)
                        REFERENCES clientes(id),
                
                    FOREIGN KEY (id_destinatario)
                        REFERENCES clientes(id),
                
                    FOREIGN KEY (placa)
                        REFERENCES veiculos(placa),
                
                    FOREIGN KEY (motorista_id)
                        REFERENCES motoristas(id)
                );
                
                CREATE INDEX IF NOT EXISTS idx_documentos_cte
                    ON documentos(numero_cte);
                
                CREATE INDEX IF NOT EXISTS idx_documentos_placa
                    ON documentos(placa);''')

        self._migrar_documentos()

    def _migrar_documentos(self):
        """Adiciona campos sem remover documentos anteriores."""
        with self.conectar() as con:
            colunas_motoristas = {
                linha["name"]
                for linha in con.execute("PRAGMA table_info(motoristas)")
            }

            if "rg" not in colunas_motoristas:
                con.execute(
                    "ALTER TABLE motoristas ADD COLUMN rg TEXT NOT NULL DEFAULT ''"
                )
            colunas = {linha['name'] for linha in con.execute('PRAGMA table_info(documentos)')}
            novos = ('tipo_documento', 'numero_documento', 'numero_nf',
                     'destinatario', 'cidade_origem', 'uf_origem', 'cidade_destino', 'uf_destino')
            faltantes = [c for c in novos if c not in colunas]
            if faltantes:
                from datetime import datetime
                backup = self.caminho.with_name(self.caminho.name + '.backup_' + datetime.now().strftime('%Y%m%d_%H%M%S_%f'))
                with sqlite3.connect(backup) as destino:
                    con.backup(destino)
            con.execute('BEGIN IMMEDIATE')
            for campo in faltantes:
                con.execute(f"ALTER TABLE documentos ADD COLUMN {campo} TEXT NOT NULL DEFAULT ''")
            con.execute("""UPDATE documentos SET
                tipo_documento = CASE substr(codigo_barras,21,2) WHEN '55' THEN 'NFE' ELSE 'CTE' END,
                numero_documento = CASE WHEN numero_cte != '' THEN numero_cte
                    ELSE COALESCE(NULLIF(ltrim(substr(codigo_barras,26,9),'0'),''),'0') END
                WHERE numero_documento = ''""")
            con.execute("UPDATE documentos SET numero_nf=numero_documento, numero_cte='' WHERE tipo_documento='NFE'")
            con.execute('CREATE INDEX IF NOT EXISTS idx_documento_numero ON documentos(numero_documento)')

    @contextmanager
    def conectar(self):
        con = sqlite3.connect(self.caminho, timeout=10)
        con.row_factory = sqlite3.Row
        con.execute('PRAGMA foreign_keys = ON')
        con.create_function('MAIUSCULA', 1, lambda valor: str(valor or '').upper())
        try:
            with con:
                yield con
        finally:
            con.close()
    def conultarClientes(self):
        with self.conectar() as con:
            registros=con.execute("SELECT nome, cidade,uf from CLIENTES ORDEM BY nome"
                                  ).fetchall()
            cidade={}

            for registro in registros:
                nome = registro["nome"].strip()
                cid = registro["cidade"]
                uf=registro['uf']

                if nome:
                    cidade.setdefault(
                        nome.casefold(),
                        {
                            "nome": nome,
                            "cid": cidade,
                            "uf":uf
                        }
                    )

            return sorted(
                cidade.values(),
                key=lambda cidade: cidade["nome"].casefold()
            )

    def listar_motoristas(self):
        """Retorna os motoristas cadastrados sem repetição."""

        with self.conectar() as con:
            registros = con.execute(
                "SELECT nome, rg FROM motoristas ORDER BY nome"
            ).fetchall()

        motoristas = {}

        for registro in registros:
            nome = registro["nome"].strip()
            rg = registro["rg"]

            if nome:
                motoristas.setdefault(
                    nome.casefold(),
                    {
                        "nome": nome,
                        "rg": rg
                    }
                )

        return sorted(
            motoristas.values(),
            key=lambda motorista: motorista["nome"].casefold()
        )
    def consultar_motorista(self, placa):
        with self.conectar() as con:
            row = con.execute('''SELECT v.placa, m.nome AS motorista
                FROM veiculos v JOIN motoristas m ON m.id=v.motorista_id
                WHERE v.placa=?''', (placa,)).fetchone()
            return dict(row) if row else None

    def salvar_motorista(self, placa, motorista, rg=""):
        """Vincula um motorista existente ou cadastra um novo com RG."""
        motorista = motorista.strip()
        rg = rg.strip()

        with self.conectar() as con:
            con.execute("BEGIN IMMEDIATE")

            veiculo = con.execute(
                "SELECT motorista_id FROM veiculos WHERE placa = ?",
                (placa,),
            ).fetchone()

            motorista_existente = next(
                (
                    registro
                    for registro in con.execute(
                    "SELECT id, nome FROM motoristas ORDER BY id"
                ).fetchall()
                    if registro["nome"].strip().casefold()
                       == motorista.casefold()
                ),
                None,
            )

            if motorista_existente:
                motorista_id = motorista_existente["id"]

                con.execute(
                    "UPDATE motoristas SET rg = ? WHERE id = ?",
                    (rg, motorista_id),
                )
            else:
                cursor = con.execute(
                    """
                    INSERT INTO motoristas (nome, rg)
                    VALUES (?, ?)
                    """,
                    (motorista, rg),
                )
                motorista_id = cursor.lastrowid

            if veiculo:
                con.execute(
                    """
                    UPDATE veiculos
                    SET motorista_id = ?
                    WHERE placa = ?
                    """,
                    (motorista_id, placa),
                )
            else:
                con.execute(
                    """
                    INSERT INTO veiculos (placa, motorista_id)
                    VALUES (?, ?)
                    """,
                    (placa, motorista_id),
                )

            return veiculo is not None


    def cadastrar_documento(self, dados):
        campos = ('remetente', 'codigo_barras', 'numero_cte', 'numero_nf',
                  'tipo_documento', 'numero_documento', 'destinatario',
                  'cidade_origem', 'uf_origem', 'cidade_destino', 'uf_destino', 'placa', 'motorista', 'data', 'observacao')
        with self.conectar() as con:
            sql = 'INSERT INTO documentos (' + ','.join(campos) + ') VALUES (' + ','.join('?' for _ in campos) + ')'
            cur = con.execute(sql, tuple(dados[c] for c in campos))
            return {'id': cur.lastrowid, **dados}

    def consultar_documentos(self, filtros):
        clausulas, valores = [], []
        for campo in ('remetente', 'codigo_barras', 'numero_cte', 'numero_nf', 'numero_documento', 'tipo_documento', 'destinatario', 'cidade_origem', 'uf_origem', 'cidade_destino', 'uf_destino', 'placa', 'motorista'):
            if campo not in filtros:
                continue
            if campo in ('remetente', 'motorista', 'destinatario', 'cidade_origem', 'cidade_destino'):
                clausulas.append(f'instr(MAIUSCULA({campo}), ?) > 0')
            else:
                clausulas.append(f'{campo} = ?')
            valores.append(filtros[campo])
        if not clausulas:
            return []
        with self.conectar() as con:
            rows = con.execute('SELECT * FROM documentos WHERE ' + ' AND '.join(clausulas) + ' ORDER BY id DESC', valores).fetchall()
            return [dict(row) for row in rows]

