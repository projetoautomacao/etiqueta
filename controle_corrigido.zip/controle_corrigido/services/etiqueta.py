"""Etiqueta HTML local para impressão pelo navegador, sem dependências extras."""


from pathlib import Path
from html import escape
import webbrowser

def gerar_etiqueta(dados, pasta=None, quantidade=1):
    """Gera uma etiqueta por palete no formato 80 x 100 mm."""
    if type(quantidade) is not int or quantidade < 1:
        raise ValueError(
            "Informe uma quantidade inteira de paletes maior que zero."
        )

    raiz = Path(__file__).resolve().parents[1]
    pasta = Path(pasta) if pasta else raiz / "etiquetas"
    pasta.mkdir(parents=True, exist_ok=True)

    identificador = int(dados["id"])

    numero_cte = str(dados.get("numero_cte") or "").strip()
    numero_nf = str(dados.get("numero_nf") or "").strip()

    tipo_documento = "CTE:" if numero_cte else "NF:"
    numero_documento = escape(numero_cte or numero_nf)

    remetente = escape(str(dados.get("remetente") or ""))
    destinatario = escape(str(dados.get("destinatario") or ""))

    cidade_destino = str(dados.get("cidade_destino") or "").strip()
    uf_destino = str(dados.get("uf_destino") or "").strip()
    cidade = escape(
        " / ".join(
            valor for valor in (cidade_destino, uf_destino)
            if valor
        )
    )

    logo = raiz / "assets" / "logo.png"

    if logo.is_file():
        import base64

        imagem = base64.b64encode(logo.read_bytes()).decode("ascii")
        marca = (
            f'<img class="logo" '
            f'src="data:image/png;base64,{imagem}" '
            f'alt="Transanches Transportes">'
        )
    else:
        marca = """
        <div class="marca">
            TRANSANCHES
            <small>TRANSPORTES</small>
        </div>
        """

    pagina = """<!doctype html>
<html lang="pt-BR">
<head>
<meta charset="utf-8">
<title>Etiquetas de transporte</title>

<style>
@page {
    size: 80mm 100mm;
    margin: 0;
}

* {
    box-sizing: border-box;
}

body {
    margin: 0;
    background: #fff;
    color: #000;
    font-family: Arial, sans-serif;
}

.etiqueta {
    width: 80mm;
    height: 100mm;
    padding: 25mm 6mm 7mm;
    overflow: hidden;
    background: #fff;
    break-after: page;
    page-break-after: always;
}

.etiqueta:last-child {
    break-after: auto;
    page-break-after: auto;
}

/* Texto horizontal. Não usar rotate. */
.layout {
    width: 100%;
    height: 100%;
    position: static;
    transform: none;
}

.cabecalho {
    height: 17mm;
    display: flex;
    align-items: center;
    justify-content: center;
}

.logo {
    width: 58mm;
    max-height: 14mm;
    object-fit: contain;
}

.marca {
    font-family: "Arial Black", Arial, sans-serif;
    font-size: 21pt;
    font-weight: 900;
    font-style: italic;
    line-height: 1;
    text-align: center;
}

.marca small {
    display: block;
    margin-top: 1mm;
    font-family: Arial, sans-serif;
    font-size: 9pt;
    font-weight: normal;
    letter-spacing: 3px;
}

.linha {
    display: flex;
    align-items: center;
    height: 10mm;
    min-width: 0;
}

.rotulo {
    flex-shrink: 0;
    font-family: "Arial Black", Arial, sans-serif;
    font-size: 18pt;
    font-weight: 900;
}

.sublinhado {
    text-decoration: underline;
    text-underline-offset: 1mm;
}

.valor {
    flex: 1;
    min-width: 0;
    margin-left: 2mm;
    font-size: 16pt;
    font-weight: bold;
    white-space: nowrap;
    overflow: hidden;
}

.rodape {
    height: 10mm;
    display: flex;
    align-items: flex-end;
    justify-content: space-between;
    padding-bottom: 2mm;
}

.sequencia {
    font-family: "Arial Black", Arial, sans-serif;
    font-size: 22pt;
    font-weight: 900;
    white-space: nowrap;
}

.acoes {
    padding: 12px;
    font-size: 14px;
}

@media print {
    .acoes {
        display: none;
    }
}
</style>
</head>

<body>
<div class="acoes">
    <button onclick="imprimir()">Imprimir todas as etiquetas</button>
    <p>Papel 80 × 100 mm, escala 100% e sem cabeçalhos e rodapés.</p>
</div>

<div class="lote">
"""

    for sequencia in range(1, quantidade + 1):
        pagina += f"""
    <main class="etiqueta">
        <div class="layout">
            <header class="cabecalho">
                {marca}
            </header>

            <div class="linha">
                <span class="rotulo sublinhado">{tipo_documento}</span>
                <span class="valor">{numero_documento}</span>
            </div>

            <div class="linha">
                <span class="rotulo">REM:</span>
                <span class="valor">{remetente}</span>
            </div>

            <div class="linha">
                <span class="rotulo sublinhado">DES:</span>
                <span class="valor">{destinatario}</span>
            </div>

            <div class="linha">
                <span class="rotulo">CID:</span>
                <span class="valor">{cidade}</span>
            </div>

            <footer class="rodape">
                <span class="rotulo">PLT/VOL:</span>
                <span class="sequencia">{sequencia} / {quantidade}</span>
            </footer>
        </div>
    </main>
"""

    pagina += """
</div>

<script>
function imprimir() {
    window.print();
}
</script>
</body>
</html>
"""

    destino = pasta / f"etiqueta_{identificador}.html"
    destino.write_text(pagina, encoding="utf-8")
    return destino
def abrir_etiqueta(dados, quantidade=1):
    caminho = gerar_etiqueta(dados, quantidade=quantidade)
    if not webbrowser.open(caminho.resolve().as_uri()):
        raise OSError(f'Não foi possível abrir o navegador. Abra o arquivo: {caminho}')
    return caminho