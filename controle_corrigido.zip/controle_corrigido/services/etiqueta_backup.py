"""Etiqueta HTML local para impressão pelo navegador, sem dependências extras."""
from html import escape
from pathlib import Path
import webbrowser


from pathlib import Path
from html import escape


def gerar_etiqueta(dados, pasta=None, quantidade=1):
    """Gera uma etiqueta por palete, no formato 80 × 100 mm."""
    if type(quantidade) is not int or quantidade < 1:
        raise ValueError(
            "Informe uma quantidade inteira de paletes maior que zero."
        )

    raiz = Path(__file__).resolve().parents[1]
    pasta = Path(pasta) if pasta else raiz / "etiquetas"
    pasta.mkdir(parents=True, exist_ok=True)

    identificador = int(dados["id"])

    # Campos sem informação permanecem em branco.
    nf = escape(str(dados.get("numero_nf") or ""))
    remetente = escape(str(dados.get("remetente") or ""))
    destinatario = escape(str(dados.get("destinatario") or ""))
    cidade = escape(" / ".join(str(dados.get(c) or "").strip() for c in ("cidade_destino", "uf_destino") if str(dados.get(c) or "").strip()))
    cte = escape(str(dados.get("numero_cte") or ""))

    # Opcional: coloque o logotipo em assets/logo.png.
    # A imagem é incorporada ao HTML para não depender do caminho depois.
    logo = raiz / "assets" / "logo.png"

    if logo.is_file():
        import base64

        imagem = base64.b64encode(logo.read_bytes()).decode("ascii")
        marca = (
            f'<img class="logo" '
            f'src="data:image/png;base64,{imagem}" '
            f'alt="Transanches Transportes">'
        )
    else:
        marca = (
            '<div class="marca">TRANSANCHES'
            '<small>TRANSPORTES</small></div>'
        )

    pagina = """<!doctype html>
<html lang="pt-BR">
<head>
<meta charset="utf-8">
<title>Etiquetas de transporte</title>

<style>
    @page {
        size: 80mm 100mm;
        margin: 0;
    }

    * {
        box-sizing: border-box;
    }

    body {
        margin: 0;
        color: #000;
        background: #fff;
        font-family: Arial, sans-serif;
    }

    .acoes {
        padding: 12px;
        font-size: 14px;
    }

    /* Cada folha corresponde a um palete. */
    .etiqueta {
        position: relative;
        width: 80mm;
        height: 100mm;
        break-after: page;
        page-break-after: always;
    }

    .etiqueta:last-child {
        break-after: auto;
        page-break-after: auto;
    }

    /*
      Área útil com margem de 4 mm.
      O conteúdo é girado 90 graus, como no modelo enviado.
    */
    .layout {
        position: absolute;
        left: 76mm;
        top: 4mm;
        width: 92mm;
        height: 72mm;
        transform-origin: top left;
        transform: rotate(90deg);
    }

    .cabecalho {
        height: 15mm;
        display: flex;
        align-items: center;
        justify-content: center;
    }

    .logo {
        max-width: 88mm;
        max-height: 14mm;
        object-fit: contain;
    }

    .marca {
        font-family: "Arial Black", Arial, sans-serif;
        font-size: 25pt;
        font-weight: 900;
        font-style: italic;
        text-align: center;
        line-height: 1;
    }

    .marca small {
        display: block;
        margin-top: 1mm;
        font-family: Arial, sans-serif;
        font-size: 9pt;
        font-weight: normal;
        letter-spacing: 3px;
    }

    .linha {
        display: flex;
        align-items: center;
        gap: 2mm;
        min-width: 0;
    }

    .documentos {
        display: grid;
        grid-template-columns: 1fr 1fr;
        gap: 3mm;
        height: 11mm;
    }

    .campo {
        height: 10mm;
    }

    .rotulo {
        flex-shrink: 0;
        font-family: "Arial Black", Arial, sans-serif;
        font-size: 19pt;
        font-weight: 900;
    }

    .sublinhado {
        text-decoration: underline;
        text-underline-offset: 1mm;
    }

    .valor {
        flex: 1;
        min-width: 0;
        font-size: 15pt;
        font-weight: bold;
        overflow-wrap: anywhere;
        line-height: 1.05;
    }

    .rodape {
        display: flex;
        align-items: center;
        justify-content: space-between;
        height: 16mm;
        gap: 3mm;
    }

    .sequencia {
        font-family: "Arial Black", Arial, sans-serif;
        font-size: 25pt;
        font-weight: 900;
        white-space: nowrap;
    }

    @media screen {
        .etiqueta {
            outline: 1px solid #ccc;
            margin: 12px auto;
        }
    }

    @media print {
        .acoes {
            display: none;
        }
    }
</style>
</head>
<body>

<div class="acoes">
    <button onclick="imprimir()">Imprimir todas as etiquetas</button>
    <p>
        Papel 80 × 100 mm, escala 100%, sem cabeçalhos e rodapés.
        Selecione todas as páginas e apenas 1 cópia.
    </p>
</div>

<div class="lote">
"""

    for sequencia in range(1, quantidade + 1):
        pagina += f"""
    <main class="etiqueta">
        <div class="layout">
            <header class="cabecalho">
                {marca}
            </header>

            <div class="documentos">
                <div class="linha">
                    <span class="rotulo sublinhado">NF:</span>
                    <span class="valor">{nf}</span>
                </div>

                <div class="linha">
                    <span class="rotulo sublinhado">CTE:</span>
                    <span class="valor">{cte}</span>
                </div>
            </div>

            <div class="linha campo">
                <span class="rotulo">REM:</span>
                <span class="valor">{remetente}</span>
            </div>

            <div class="linha campo">
                <span class="rotulo sublinhado">DES:</span>
                <span class="valor">{destinatario}</span>
            </div>

            <div class="linha campo">
                <span class="rotulo">CID:</span>
                <span class="valor">{cidade}</span>
            </div>

            <footer class="rodape">
                <span class="rotulo">PLT/VOL:</span>
                <span class="sequencia">{sequencia} / {quantidade}</span>
            </footer>
        </div>
    </main>
"""

    pagina += """
</div>

<script>
function ajustar() {
    let cabe = true;

    for (const valor of document.querySelectorAll('.valor')) {
        let tamanho = 20;
        valor.style.fontSize = tamanho + 'px';

        while (
            (valor.scrollWidth > valor.clientWidth ||
             valor.scrollHeight > valor.parentElement.clientHeight) &&
            tamanho > 8
        ) {
            tamanho -= 0.5;
            valor.style.fontSize = tamanho + 'px';
        }

        if (
            valor.scrollWidth > valor.clientWidth ||
            valor.scrollHeight > valor.parentElement.clientHeight
        ) {
            cabe = false;
        }
    }

    return cabe;
}

function imprimir() {
    if (!ajustar()) {
        alert(
            'Há um campo muito longo para a etiqueta. ' +
            'Revise os dados antes de imprimir.'
        );
        return;
    }

    window.print();
}

window.addEventListener('beforeprint', ajustar);

window.addEventListener('load', async () => {
    await document.fonts.ready;
    imprimir();
});
</script>
</body>
</html>
"""

    destino = pasta / f"etiqueta_{identificador}.html"
    destino.write_text(pagina, encoding="utf-8")
    return destino

def abrir_etiqueta(dados, quantidade=1):
    caminho = gerar_etiqueta(dados, quantidade=quantidade)
    if not webbrowser.open(caminho.resolve().as_uri()):
        raise OSError(f'Não foi possível abrir o navegador. Abra o arquivo: {caminho}')
    return caminho
