import tempfile
import unittest
from pathlib import Path
from controllers.controller import Controller


class BancoTest(unittest.TestCase):
    def test_fluxo_persistente(self):
        with tempfile.TemporaryDirectory() as pasta:
            caminho = Path(pasta) / 'teste.db'
            c = Controller(caminho)
            self.assertTrue(c.atualizar_motorista({'placa': 'abc1234', 'motorista': 'João'})['sucesso'])
            c.atualizar_motorista({'placa': 'DEF5678', 'motorista': 'João'})
            def documento(numero, emissor='06014528000104'):
                chave = '352609' + emissor + '57' + '001' + f'{numero:09}' + '1' + '00001001' + '0'
                return dict(destinatario='CLIENTE B', cidade_destino='Curitiba', uf_destino='PR', remetente='EMPRESA A', codigo_barras=chave, numero_cte=str(numero), placa='abc1234', motorista='João', data='18/09/2026', observacao='Carga frágil')
            d = documento(1001)
            self.assertTrue(c.cadastrar(d)['sucesso'])
            self.assertFalse(c.cadastrar(d)['sucesso'])
            self.assertTrue(c.cadastrar(documento(1002))['sucesso'])
            # Mesmo número em outra chave: não esconder registros da consulta.
            self.assertTrue(c.cadastrar(documento(1001, '11111111000111'))['sucesso'])
            self.assertEqual(c.consultar({'numero_cte': '1001'})['tipo_retorno'], 'multiplo')
            self.assertEqual(c.consultar({'remetente': 'empresa'})['quantidade'], 3)
            self.assertEqual(c.consultar({'motorista': 'joão'})['quantidade'], 3)
            self.assertFalse(c.consultar({'remetente': "' OR 1=1 --"})['sucesso'])
            self.assertFalse(c.cadastrar({**documento(1003), 'data': '31/02/2026'})['sucesso'])
            self.assertEqual(c.cadastrar({**documento(1003), 'numero_cte': '9'})['dados']['numero_documento'], '1003')
            c.atualizar_motorista({'placa': 'ABC-1234', 'motorista': 'Maria'})
            novo = Controller(caminho)
            self.assertEqual(novo.consultar_motorista_por_placa('abc1234')['dados']['motorista'], 'Maria')
            self.assertEqual(novo.consultar_motorista_por_placa('def5678')['dados']['motorista'], 'João')
            salvo = novo.consultar({'codigo_barras': d['codigo_barras']})['dados'][0]
            self.assertEqual(salvo['motorista'], 'João')
            self.assertEqual(salvo['observacao'], 'Carga frágil')
            self.assertEqual(salvo['data'], '18/09/2026')
            self.assertFalse(novo.cadastrar(documento(1004))['sucesso'])


if __name__ == '__main__':
    unittest.main()
