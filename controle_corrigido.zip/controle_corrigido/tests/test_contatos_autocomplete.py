import tempfile
import unittest
from pathlib import Path

from controllers.controller import Controller


class ContatosTest(unittest.TestCase):
    def test_motorista_rg_e_grafia(self):
        with tempfile.TemporaryDirectory() as pasta:
            db = Path(pasta) / "teste.db"
            c = Controller(db)
            self.assertTrue(c.atualizar_motorista({"placa": "ABC1234", "motorista": "João", "rg": "123"})["sucesso"])
            resultado = c.atualizar_motorista({"placa": "DEF5678", "motorista": "JOÃO"})
            self.assertTrue(resultado["sucesso"])
            self.assertEqual(resultado["dados"]["motorista"], "João")
            self.assertEqual(resultado["dados"]["rg"], "123")

    def test_consultar_clientes(self):
        with tempfile.TemporaryDirectory() as pasta:
            db = Path(pasta) / "teste.db"
            c = Controller(db)
            with c.repository.conectar() as con:
                con.execute(
                    "INSERT INTO clientes(nome, cpf_cnpj, cidade, uf) VALUES (?, ?, ?, ?)",
                    ("Cliente Teste", "123", "Curitiba", "PR"),
                )
            clientes = c.consultar_clientes()
            self.assertEqual(clientes[0]["nome"], "Cliente Teste")
            self.assertEqual(clientes[0]["cidade"], "Curitiba")
            self.assertEqual(clientes[0]["uf"], "PR")


if __name__ == "__main__":
    unittest.main()
