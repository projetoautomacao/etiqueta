import sqlite3
import tempfile
import unittest
from pathlib import Path
from unittest.mock import Mock
from controllers.controller import Controller
from views.dashboard_view import DashboardCTe
from services.etiqueta import gerar_etiqueta

class DocumentosTest(unittest.TestCase):
    def test_nfe_cte_destino(self):
        with tempfile.TemporaryDirectory() as d:
            c=Controller(Path(d)/'banco.db')
            c.atualizar_motorista({'placa':'ABC1234','motorista':'João'})
            for modelo,tipo in [('55','NFE'),('57','CTE')]:
                chave='352609'+'06014528000104'+modelo+'001'+'000001234'+'1'+'00001001'+'0'
                dados=dict(codigo_barras=chave,remetente='A',destinatario='B',cidade_origem='São Paulo',uf_origem='sp',cidade_destino='Curitiba',uf_destino='pr',placa='ABC1234',motorista='João',data='22/09/2026')
                self.assertFalse(c.cadastrar({**dados,'uf_destino':'XX'})['sucesso'])
                self.assertFalse(c.cadastrar({**dados,'cidade_destino':''})['sucesso'])
                res=c.cadastrar(dados)
                self.assertTrue(res['sucesso'],res)
                salvo=res['dados']
                self.assertEqual(salvo['uf_origem'], 'SP')
                self.assertFalse(c.cadastrar({**dados, 'uf_origem':'XX'})['sucesso'])
                self.assertEqual(salvo['tipo_documento'],tipo)
                self.assertEqual(salvo['numero_documento'],'1234')
                self.assertEqual(salvo['numero_nf' if tipo=='CTE' else 'numero_cte'],'')
                html=gerar_etiqueta(salvo,d,3).read_text()
                self.assertEqual(html.count('<main class="etiqueta">'),3)
                self.assertIn('Curitiba / PR',html)
                self.assertFalse(c.cadastrar(dados)['sucesso'])
            novo=Controller(Path(d)/'banco.db')
            self.assertEqual(novo.consultar({'cidade_origem':'são', 'uf_origem':'sp'})['quantidade'],2)
            self.assertEqual(novo.consultar({'numero_documento':'001234'})['quantidade'],2)
            self.assertEqual(novo.consultar({'cidade_destino':'curi','uf_destino':'PR','destinatario':'B'})['quantidade'],2)

    def test_migracao_preserva_e_backup(self):
        with tempfile.TemporaryDirectory() as d:
            db=Path(d)/'antigo.db'
            with sqlite3.connect(db) as con:
                con.executescript("""CREATE TABLE documentos(id INTEGER PRIMARY KEY, remetente TEXT NOT NULL,codigo_barras TEXT UNIQUE NOT NULL,numero_cte TEXT NOT NULL,placa TEXT NOT NULL,motorista TEXT NOT NULL,data TEXT NOT NULL,observacao TEXT NOT NULL DEFAULT '');
                INSERT INTO documentos VALUES(42,'A','35260906014528000104570010000012341000010010','1234','ABC-1234','João','22/09/2026','Histórico');""")
            c=Controller(db)
            row=c.consultar({'numero_documento':'1234'})['dados'][0]
            self.assertEqual(row['id'],42)
            self.assertEqual(row['observacao'],'Histórico')
            self.assertEqual(row['cidade_destino'],'')
            self.assertEqual(row['cidade_origem'],'')
            self.assertEqual(row['uf_origem'],'')
            self.assertEqual(len(list(Path(d).glob('*.backup_*'))),1)
            Controller(db)
            self.assertEqual(len(list(Path(d).glob('*.backup_*'))),1)
            with sqlite3.connect(db) as con:
                self.assertEqual(con.execute('PRAGMA integrity_check').fetchone()[0],'ok')

    def test_trocar_documento_limpar_e_preencher(self):
        tela=Mock()
        tela.controller=Mock()
        tela.codigo_var.get.return_value='chave'
        for tipo in ('CTE','NFE'):
            tela.controller.extrair_numero_cte_nf.return_value={'sucesso':True,'numero_cte':'123' if tipo=='CTE' else '', 'numero_nf':'456' if tipo=='NFE' else ''}
            self.assertTrue(DashboardCTe._extrair_numero_cte_nfe(tela))
            tela.numero_documento_var.set.assert_called_with('123' if tipo=='CTE' else '456')
        tela.codigo_var.get.return_value=''
        self.assertFalse(DashboardCTe._extrair_numero_cte_nfe(tela))
        tela.numero_documento_var.set.assert_called_with('')
        DashboardCTe._preencher_formulario(tela, {'numero_documento':'456','cidade_origem':'São Paulo','uf_origem':'SP','cidade_destino':'Curitiba','uf_destino':'PR','destinatario':'B'})
        tela.cidade_destino_var.set.assert_called_with('Curitiba')
        tela.cidade_origem_var.set.assert_called_with('São Paulo')
        tela.uf_origem_var.set.assert_called_with('SP')
        DashboardCTe._limpar_formulario_principal(tela)
        for campo in ('numero_documento_var','destinatario_var','cidade_destino_var','uf_destino_var','cidade_origem_var','uf_origem_var'):
            getattr(tela,campo).set.assert_called_with('')
