import tempfile
import unittest
from pathlib import Path
from unittest.mock import Mock, patch
from views.dashboard_view import DashboardCTe
from controllers.controller import Controller
from services.etiqueta import gerar_etiqueta


class FluxoTest(unittest.TestCase):
    def setUp(self):
        patcher = patch('views.dashboard_view.simpledialog.askinteger', return_value=3)
        patcher.start()
        self.addCleanup(patcher.stop)

    def test_cancelar_quantidade(self):
        tela = self.tela()
        with patch('views.dashboard_view.messagebox.askyesno', return_value=True), patch('views.dashboard_view.simpledialog.askinteger', return_value=None), patch('views.dashboard_view.abrir_etiqueta') as abrir:
            DashboardCTe._executar_acao(tela, lambda d: {'sucesso': True, 'dados': {'id': 1}}, 'ok', True)
            abrir.assert_not_called()
        tela._limpar_formulario_principal.assert_called_once()

    def test_sequencia(self):
        with tempfile.TemporaryDirectory() as pasta:
            for n in (1, 3, 12):
                html = gerar_etiqueta({'id': 1, 'numero_cte': '12345'}, pasta, quantidade=n).read_text()
                self.assertEqual(html.count('>12345</span>'), n)
                self.assertEqual(html.count('<main '), n)
                for i in range(1, n + 1):
                    self.assertIn(f'{i} / {n}</span>', html)
            for invalido in (0, -1, 1.5, True):
                with self.assertRaises(ValueError):
                    gerar_etiqueta({'id': 1}, pasta, quantidade=invalido)

    def tela(self):
        tela = Mock()
        tela._obter_dados_formulario.return_value = {'numero_cte': '123'}
        return tela

    def test_sim_imprime_dados_salvos_antes_de_limpar(self):
        tela = self.tela()
        dados = {'id': 7, 'numero_cte': '123'}
        with patch('views.dashboard_view.messagebox.askyesno', return_value=True), patch('views.dashboard_view.abrir_etiqueta') as abrir:
            abrir.side_effect = lambda d, **kwargs: tela._limpar_formulario_principal.assert_not_called()
            DashboardCTe._executar_acao(tela, lambda d: {'sucesso': True, 'dados': dados}, 'ok', True)
            abrir.assert_called_once_with(dados, quantidade=3)
        tela._limpar_formulario_principal.assert_called_once()

    def test_nao_e_cadastro_invalido(self):
        for sucesso in (False, True):
            tela = self.tela()
            with patch('views.dashboard_view.messagebox.askyesno', return_value=False) as pergunta, patch('views.dashboard_view.abrir_etiqueta') as abrir:
                DashboardCTe._executar_acao(tela, lambda d: {'sucesso': sucesso, 'dados': d}, 'ok', True)
                self.assertEqual(pergunta.call_count, int(sucesso))
                abrir.assert_not_called()

    def test_falha_impressao_nao_repete_cadastro(self):
        tela = self.tela()
        acao = Mock(return_value={'sucesso': True, 'dados': {'id': 1}})
        with patch('views.dashboard_view.messagebox.askyesno', return_value=True), patch('views.dashboard_view.abrir_etiqueta', side_effect=OSError('falha')), patch('views.dashboard_view.messagebox.showwarning') as aviso:
            DashboardCTe._executar_acao(tela, acao, 'ok', True)
            aviso.assert_called_once()
            acao.assert_called_once()

    def test_fechar_modal_nao_limpa_registro(self):
        tela = self.tela()
        DashboardCTe._fechar_modal_resultados(tela)
        tela._perguntar_nova_consulta.assert_not_called()
        tela._limpar_formulario_principal.assert_not_called()

    def test_grafia_motorista_e_html(self):
        with tempfile.TemporaryDirectory() as pasta:
            c = Controller(Path(pasta) / 'teste.db')
            c.atualizar_motorista({'placa': 'ABC1234', 'motorista': 'João'})
            resultado = c.atualizar_motorista({'placa': 'DEF5678', 'motorista': 'JOÃO'})
            self.assertEqual(resultado['dados']['motorista'], 'João')
            self.assertEqual([m['nome'] for m in c.listar_motoristas()], ['João'])
            p = gerar_etiqueta({'id': 1, 'numero_cte': '123', 'remetente': '<script>alert(1)</script>'}, pasta)
            html = p.read_text()
            self.assertIn('&lt;script&gt;', html)
            self.assertIn('80mm 100mm', html)
