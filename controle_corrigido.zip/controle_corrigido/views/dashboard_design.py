"""Configuração visual do dashboard de CT-e.

Este módulo contém somente cores, fontes, tamanhos, espaçamentos e estilos.
Não possui consultas, validações, banco de dados ou regras de negócio.
"""

from tkinter import ttk


# ============================================================
# CORES
# ============================================================
NAVY = "#001D59"
NAVY_2 = "#062B70"
BLUE = "#174A9C"
BLUE_LIGHT = "#EAF1FB"
WHITE = "#FFFFFF"
BG = "#F4F7FB"
TEXT = "#1D2939"
MUTED = "#667085"
BORDER = "#D8E0EC"
SUCCESS = "#198754"
DANGER = "#C93636"


# ============================================================
# JANELA E DIMENSÕES
# ============================================================
WINDOW_TITLE = "Transanches Transportes - Dashboard"
WINDOW_SIZE = "1000x680"
WINDOW_MIN_WIDTH = 800
WINDOW_MIN_HEIGHT = 480

TOPBAR_HEIGHT = 54
FOOTER_HEIGHT = 90

CONTENT_PAD_X = 18
CONTENT_PAD_TOP = 2
CONTENT_PAD_BOTTOM = 10

FORM_PAD_X = 14
FORM_PAD_Y = 6
FIELD_PAD_X = 7
FIELD_PAD_BOTTOM = 6


# ============================================================
# FONTES
# ============================================================
FONT_FAMILY = "Segoe UI"
FONT_NORMAL = (FONT_FAMILY, 10)
FONT_SMALL = (FONT_FAMILY, 9)
FONT_HELP = (FONT_FAMILY, 8)
FONT_LABEL = ("Segoe UI Semibold", 9)
FONT_BUTTON = ("Segoe UI Semibold", 9)
FONT_TITLE = (FONT_FAMILY, 19, "bold")
FONT_SECTION = (FONT_FAMILY, 14, "bold")
FONT_CARD_VALUE = (FONT_FAMILY, 16, "bold")


# ============================================================
# CONFIGURAÇÕES DE WIDGETS TKINTER
# Use assim: tk.Label(parent, **LABEL_MUTED)
# ============================================================
LABEL_NORMAL = {
    "font": FONT_NORMAL,
    "fg": TEXT,
    "bg": WHITE,
}

LABEL_MUTED = {
    "font": FONT_SMALL,
    "fg": MUTED,
    "bg": WHITE,
}

TITLE_STYLE = {
    "font": FONT_TITLE,
    "fg": NAVY,
    "bg": BG,
}

SECTION_TITLE_STYLE = {
    "font": FONT_SECTION,
    "fg": NAVY,
    "bg": WHITE,
}

CARD_STYLE = {
    "bg": WHITE,
    "highlightbackground": BORDER,
    "highlightthickness": 1,
}

FORM_CONTAINER_STYLE = {
    "bg": WHITE,
    "highlightbackground": BORDER,
    "highlightthickness": 1,
}

BUTTON_PRIMARY = {
    "font": FONT_BUTTON,
    "bg": BLUE,
    "fg": WHITE,
    "activebackground": NAVY_2,
    "activeforeground": WHITE,
    "relief": "flat",
    "bd": 0,
    "highlightthickness": 0,
    "padx": 14,
    "pady": 7,
    "width": 12,
    "cursor": "hand2",
}

BUTTON_SECONDARY = {
    **BUTTON_PRIMARY,
    "bg": NAVY_2,
    "activebackground": NAVY,
}

BUTTON_OUTLINE = {
    **BUTTON_PRIMARY,
    "bg": WHITE,
    "fg": NAVY,
    "activebackground": "#E7EEF8",
    "activeforeground": NAVY,
    "relief": "solid",
    "bd": 1,
}


# ============================================================
# ESTILOS TTK
# ============================================================
def configurar_estilos(janela):
    """Aplica os estilos visuais aos componentes ttk da janela."""
    estilo = ttk.Style(janela)
    estilo.theme_use("clam")

    estilo.configure(
        "TEntry",
        fieldbackground=WHITE,
        background=WHITE,
        foreground=TEXT,
        bordercolor=BORDER,
        lightcolor=BORDER,
        darkcolor=BORDER,
        padding=(8, 4),
        font=FONT_NORMAL,
        borderwidth=1,
        relief="solid",
    )

    estilo.map(
        "TEntry",
        bordercolor=[("focus", BLUE), ("!focus", BORDER)],
        lightcolor=[("focus", BLUE), ("!focus", BORDER)],
        darkcolor=[("focus", BLUE), ("!focus", BORDER)],
    )

    estilo.configure(
        "TCombobox",
        fieldbackground=WHITE,
        background=WHITE,
        foreground=TEXT,
        bordercolor=BORDER,
        padding=(8, 4),
        font=FONT_NORMAL,
        borderwidth=1,
        relief="solid",
    )

    estilo.configure(
        "Treeview",
        background=WHITE,
        fieldbackground=WHITE,
        foreground=TEXT,
        rowheight=34,
        bordercolor=BORDER,
        font=FONT_SMALL,
    )

    estilo.configure(
        "Treeview.Heading",
        background=BLUE_LIGHT,
        foreground=NAVY,
        font=FONT_LABEL,
        padding=8,
    )

    estilo.configure(
        "Data.TEntry",
        fieldbackground="#E9ECEF",
        foreground="#495057",
        bordercolor=BORDER,
        lightcolor=BORDER,
        darkcolor=BORDER,
        padding=(8, 4),
        font=FONT_NORMAL,
        borderwidth=1,
        relief="solid",
    )

    estilo.map(
        "Treeview",
        background=[("selected", "#DCE9FA")],
        foreground=[("selected", TEXT)],
    )

    return estilo


